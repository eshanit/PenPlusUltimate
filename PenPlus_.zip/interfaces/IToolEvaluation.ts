interface ToolEvaluation {
    label: string,
    name: string,
    threeCompleted: number,
    twoCompleted: number,
    oneCompleted: number,
    totalCompleted: number
}

type IToolEvaluation = Readonly<ToolEvaluation>

export type { IToolEvaluation as default }