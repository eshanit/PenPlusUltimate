import type IFinalEvaluation from "@/interfaces/IFinalEvaluation";
import type ISession from "~/interfaces/ISession";

export function useLatestSessionEvals(evaluations: Array<IFinalEvaluation>) {
   

    const completedEvaluations = evaluations.filter((evaluation) => {
        const sessions: any= evaluation.sessions;
        return sessions.session_1 && sessions.session_2 && sessions.session_3;
      });
    
      const completed2Evals = evaluations.filter((evaluation) => {
    
        const sessions:any = evaluation.sessions;
        return sessions.session_1 && sessions.session_2 && sessions.session_3 == null;
       
      });
    
      const completed1Evals = evaluations.filter((evaluation) => {
    
        const sessions: any = evaluation.sessions;
        return sessions.session_1 && sessions.session_2 == null && sessions.session_3 == null;
       
      });

      // for those with 3 sessions

      const latestSession3Scores = completedEvaluations.map(evaluation => {
        const sessions = evaluation.sessions;
        const latestSessionKey:any = "session_3"; // Get the latest session key
        const latestSession:any = sessions[latestSessionKey];
    
        return {
            _id: evaluation._id,
            evaluator: evaluation.evaluator,
            evaluationID: evaluation.evaluationID,
            mentee: evaluation.mentee,
            tool: evaluation.tool,
            latestSession: latestSessionKey,
            scores: latestSession.evalItemScores || null // Scores might be null
        };
    });

      // for those with 2 sessions

      const latestSession2Scores = completed2Evals.map(evaluation => {
        const sessions = evaluation.sessions;
        const latestSessionKey:any = "session_2"; // Get the latest session key
        const latestSession:any = sessions[latestSessionKey];
    
        return {
            _id: evaluation._id,
            evaluator: evaluation.evaluator,
            evaluationID: evaluation.evaluationID,
            mentee: evaluation.mentee,
            tool: evaluation.tool,
            latestSession: latestSessionKey,
            scores: latestSession.evalItemScores || null // Scores might be null
        };
    })
    
      // for those with 2 sessions

      const latestSession1Scores = completed1Evals.map(evaluation => {
        const sessions = evaluation.sessions;
        const latestSessionKey:any = "session_1"; // Get the latest session key
        const latestSession:any = sessions[latestSessionKey];
    
        return {
            _id: evaluation._id,
            evaluator: evaluation.evaluator,
            evaluationID: evaluation.evaluationID,
            mentee: evaluation.mentee,
            tool: evaluation.tool,
            latestSession: latestSessionKey,
            scores: latestSession.evalItemScores || null // Scores might be null
        };
    })
    

    return [latestSession1Scores, latestSession2Scores, latestSession3Scores].flat()
}