<script setup lang="ts">
</script>
<template>
    <!-- <div class="bg-[url('/assets/img/solidarmed.png')] bg-no-repeat bg-right-bottom"> -->
        <UContainer>
            <div class=" flex items-center justify-center h-screen">
                <UCard>
                    <FormsRegister />
                </UCard>
            </div>
        </UContainer>
    <!-- </div> -->
</template>