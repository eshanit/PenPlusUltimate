<script setup lang="ts">
import type IDistrict from "@/interfaces/IDistrict";
import Routes from '@/constants/Routes';
import DatabaseNames from "@/constants/DatabaseNames";
import ToolEvaluations from "~/components/tables/AGtables/Dashboard/ToolEvaluations.vue";

const facilities: Ref<Array<string>> = ref([])

const user = useUserDetails;

//districts

const useDistricts = useDistrictsStore();

const districts: Array<IDistrict> = await useDistricts.fetchDistricts();

districts?.forEach((d: any) => {
    facilities.value.push(d.facilities);
})

//mentees
const useMentees = useMenteeStore();

const mentees = await useMentees.fetchMentees();

//evaluations
const useEvaluations = useEvalDataStore();

const completedEvals = await useEvaluations.fetchEvaluationScores(DatabaseNames.COMPLETED_EVALUTATIONS);

const evaluationStats = useEvaluationStats(completedEvals)

//progress tracking
const tools = useTools


const countToolSessions = computed(() => {
    const arr: any[] = []
    tools.forEach((tool) => {
        const countSessions = useCountToolSessionsCompleted(tool.name, evaluationStats)
        arr.push({
            label: tool.label,
            name: tool.name,
            fiveCompleted: countSessions.allCompletedCount,
            fourCompleted: countSessions.fourCompleted,
            threeCompleted: countSessions.threeCompleted,
            twoCompleted: countSessions.twoCompletedCount,
            oneCompleted: countSessions.oneCompletedCount,
            totalCompleted: countSessions.totalCompletedCount
        })
    });

    return arr
})

const maxCompletedTool = countToolSessions.value.reduce((max, current) => {
    return (current.totalCompleted > max.totalCompleted) ? current : max;
});

const minCompletedTool = countToolSessions.value.reduce((min, current) => {
    return (current.totalCompleted > min.totalCompleted) ? current : min;
});

const totalSessionMinMaxTool = computed(() => {

    const maxEvals = maxCompletedTool.totalCompleted
    const maxSessions = maxCompletedTool.oneCompleted + 2*maxCompletedTool.twoCompleted + 3*maxCompletedTool.threeCompleted + 4*maxCompletedTool.fourCompleted + 5*maxCompletedTool.fiveCompleted

    ///
    const minEvals = minCompletedTool.totalCompleted
    const minSessions = minCompletedTool.oneCompleted + 2*minCompletedTool.twoCompleted + 3*minCompletedTool.threeCompleted + 4*minCompletedTool.fourCompleted + 5*minCompletedTool.fiveCompleted

    return {
        min: {
            evals: minEvals,
            sessions: minSessions
        },
        max: {
            evals: maxEvals,
            sessions: maxSessions
        }
    }

})

//
const countAllSessions = computed(() => {
    return  (evaluationStats.completed1Evals.length + 2*evaluationStats.completed2Evals.length +  3*evaluationStats.completed3Evals.length+ 4*evaluationStats.completed4Evals.length + 5*evaluationStats.completedEvaluations.length)
})

//
const showToolChartPerc: Ref<Boolean> = ref(false)
const showFacilityChartPerc: Ref<Boolean> = ref(false)

</script>

<template>
    <SharedNavBar>
        <template #lead>
            <div class="font-bold text-red-700">
                Dashboard
            </div>
        </template>
    </SharedNavBar>

    <UDivider label="Key Performance Indicators" />

    <UContainer>
        <!-- Your content here -->
        <div class="flex justify-between pt-20 gap-5">

            <UCard
                class="flex-grow text-center text-sky-800 rounded-lg hover:bg-sky-400 hover:shadow-lg  hover:text-white ">
                <NuxtLink :to="Routes.DISTRICTS_REPORTING.path">
                    <div class="border-b">Districts</div>
                    <div class="text-5xl ">{{ districts?.length }}</div>
                </NuxtLink>
            </UCard>

            <UCard
                class="flex-grow text-center text-sky-800 rounded-lg hover:bg-sky-400 hover:shadow-lg  hover:text-white">
                <NuxtLink :to="Routes.FACILITIES_REPORTING.path">
                    <div class="border-b">Facilities</div>
                    <div class="text-5xl">{{ facilities?.flat().length }}</div>
                </NuxtLink>
            </UCard>
            <UCard
                class="flex-grow text-center text-sky-800 rounded-lg hover:bg-sky-400 hover:shadow-lg  hover:text-white">
                <NuxtLink :to="Routes.MENTEES_REPORTING.path">
                    <div class="border-b">Mentees/Providers</div>
                    <div class="text-5xl">{{ mentees?.length }}</div>
                </NuxtLink>
            </UCard>
            <UCard class="flex-grow text-center cursor-pointer" @click="useDownloadEvaluations(completedEvals)">
                <div class="border-b">Evaluations</div>
                <div class="text-5xl">{{ completedEvals?.length }}</div>
            </UCard>
        </div>
        <div class="py-10" />
        <!-- <pre>
            {{evaluationStats}}
        </pre> -->
        <div class="grid grid-cols-2 gap-5">
            <UCard class="bg-gray-100 ">
                <!-- <template #body> -->
                <div class="text-center">
                    <div class="font-bold py-5">Most Evaluated Tool </div>
                    <div class="text-5xl text-sky-500 ">{{ maxCompletedTool.label }}</div>   
                </div>
                <!-- </template> -->
                <template #footer>
                        <div>
                            This tool has <span class="text-orange-500 font-semibold italic">{{ totalSessionMinMaxTool.max.evals }}</span> Evaluations amounting to <span class="text-orange-500 font-semibold italic">{{ totalSessionMinMaxTool.max.sessions }}</span> sessions
                        </div>
                    </template>
            </UCard>
            <UCard class="bg-gray-100 ">
                <!-- <template #body> -->
                <div class="text-center">
                    <div class="font-bold py-5">Sessions </div>
                    <div class="text-5xl text-orange-500 ">{{ countAllSessions
                    }}</div>
                </div>
                <!-- </template> -->
            </UCard>
        </div>

        <UDivider label="Progress Tracking" class="py-10" />
        <div ref="NCD Tool Eval" class="pb-10">

            <UCard class="bg-green-50">
                <template #header>
                    <div class="font-bold pb-5 text-orange-500">Evaluations by NCD Tool/Disease:</div>
                </template>
                <div class="text-sky-900">
                    The charts below show the number of evaluation-sessions done for each disease. Its broken down by
                    number
                    of evaluations with
                    1 session, 2 sessions, 3 sessions, 4 sessions and 5 sessions. A completed evaluation is one with 5 sessions.
                </div>
                <div class="py-5">
                    <div v-if="showToolChartPerc">
                        <div class="pb-2.5">
                            <UButton @click="showToolChartPerc = false">
                                View Counts
                            </UButton>
                        </div>
                        <ChartsDashboardToolsStackedPerc :count-tool-sessions="countToolSessions" />

                    </div>
                    <div v-else>
                        <div class="pb-2.5">
                            <UButton @click="showToolChartPerc = true">
                                View Percentages
                            </UButton>
                        </div>
                        <ChartsDashboardToolsStacked :count-tool-sessions="countToolSessions" />
                    </div>
                </div>
                <div>
                    <TablesAGtablesDashboardToolEvaluations :evaluation-stats="evaluationStats" />
                </div>
            </UCard>

        </div>

        <UCard class="bg-sky-50 pb-10">
            <template #header>
                <div class="font-bold pb-5 text-orange-500">Evaluations by Facility:</div>
            </template>
            <div class="text-sky-900">
                The charts below show the number of evaluation-sessions done for each <span
                    class="font-semibold">Facility</span>. Its broken down by number of evaluations with
                1 session, 2 sessions and 3 sessions. A completed evaluation is one with 3 sessions.
            </div>

            <div class="py-5">
                <div v-if="showFacilityChartPerc">
                    <div class="pb-2.5">
                        <UButton @click="showFacilityChartPerc = false">
                            View Counts
                            <template #trailing></template>
                        </UButton>
                    </div>
                    <ChartsDashboardFacilitiesStackedPerc :evaluation-stats="evaluationStats"
                        :facilities="facilities?.flat()" />

                </div>
                <div v-else>
                    <div class="pb-2.5">
                        <UButton @click="showFacilityChartPerc = true">
                            View Percentages
                        </UButton>
                    </div>
                    <ChartsDashboardFacilitiesStacked :evaluation-stats="evaluationStats"
                        :facilities="facilities?.flat()" />
                </div>
            </div>
            <TablesAGtablesDashboardFacilityEvaluations :evaluation-stats="evaluationStats"
                :facilities="facilities?.flat()" />
        </UCard>
        <div class="pb-10" />
    </UContainer>
</template>

<style scoped>
/* Additional custom styles */

.text-pretty {
    color: #3B82F6;
    /* Sky color */
}

.icon-size {
    width: 100%;
    /* Fill the container width */
    height: auto;
    /* Maintain aspect ratio */
    max-height: 100px;
    /* Limit height for larger icons */
}

@media (max-width: 768px) {
    .text-lg {
        font-size: 1.5rem;
        /* Larger text on mobile */
    }

    .icon-size {
        max-height: 80px;
        /* Adjust icon size for smaller screens */
    }
}
</style>