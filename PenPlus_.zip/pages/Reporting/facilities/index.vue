<script setup lang="ts">
import type IDistrict from "@/interfaces/IDistrict";
import Routes from '@/constants/Routes';
import DatabaseNames from "@/constants/DatabaseNames";
import { computedAsync } from "@vueuse/core";

const router = useRouter();

const goBack = () => {
    router.back();
};
//

const facilities: Ref<Array<string>> = ref([])

//districts
const useDistricts = useDistrictsStore();

const districts: Array<IDistrict> = await useDistricts.fetchDistricts();

districts?.forEach((d: any) => {
    facilities.value.push(d.facilities);
})

//stats
const facilityMenteeCounts: Ref<Array<any>> = ref([])
const facilityEvalCounts: Ref<Array<any>> = ref([])

// mentees
const useMentees = useMenteeStore()

const facilityMentees = async (facility: string) => {

    return await useMentees.fetchAllMentees(facility)

}
//
//evaluations
const useEvaluations = useEvalDataStore();

const completedEvals = await useEvaluations.fetchEvaluationScores(DatabaseNames.COMPLETED_EVALUTATIONS);

const evaluationStats = useEvaluationStats(completedEvals)

const countSessionsFacility = (facility: string) => {
    const allCompleted = evaluationStats.completedEvaluations.filter((el) => {
        return el.mentee.facility == facility
    })

    const twoCompleted = evaluationStats.completed2Evals.filter((el) => {
        return el.mentee.facility == facility
    })

    const oneCompleted = evaluationStats.completed1Evals.filter((el) => {
        return el.mentee.facility == facility
    })

    const allEvaluations = completedEvals.filter((el: any) => {
        return (el.mentee.facility == facility)
    })

    //means
    let allScores = [];
    allScores = allEvaluations.map((el: any) => {
        return el.sessions
    })

    let allSessions = [];
    allSessions = allScores.map((el: any) => {
        return [
            el.session_1?.evalItemScores,
            el.session_2?.evalItemScores,
            el.session_3?.evalItemScores
        ].flat(2).filter(item => item != null)
    })
    // console.log(Array.isArray(allSessions[0]));
    // Flatten the array and map scores to numbers
    const flattenedScores = allSessions.flat().map((item: any) => parseFloat(item.score));

    // Calculate the sum and count of scores
    const totalScore = flattenedScores.reduce((sum: any, score: any) => sum + score, 0);
    const count = flattenedScores.length;

    // Calculate the mean score
    const meanScore = count > 0 ? (totalScore / count).toFixed(2) : "0.00";

    return {
        allCompletedCount: allCompleted.length,
        twoCompletedCount: twoCompleted.length,
        oneCompletedCount: oneCompleted.length,
        // Means
        allCompletedMean: meanScore
    }
}

//
computedAsync(() => {
    const allPromises: any[] = [];

    facilities.value.flat().forEach((f: any) => allPromises.push(
        //

        facilityMentees(f).then((mentees) => {

            facilityMenteeCounts.value.push({
                facility: f,
                mentees: mentees?.length
            })

            //facility 
            facilityEvalCounts.value.push({
                facility: f,
                completedEvals: countSessionsFacility(f).allCompletedCount,
                twoCompletedEvals: countSessionsFacility(f).twoCompletedCount,
                oneCompletedEvals: countSessionsFacility(f).oneCompletedCount,
                totalEvals: countSessionsFacility(f).allCompletedCount +
                    countSessionsFacility(f).twoCompletedCount
                    + countSessionsFacility(f).oneCompletedCount
            })
        }),

        //
    ))


    Promise.all(allPromises)

})

</script>
<template>
    <SharedBorderedNavBar>
        <template #lead>
            <!-- <NuxtLink :to="Routes.COMPLETED_EVALUATIONS.path"> -->
            <div class="pr-5 text-blue-500 cursor-pointer" @click="goBack">
                <UIcon name="i-heroicons-arrow-small-left" />
            </div>
            <!-- </NuxtLink> -->
            <div>
                <span class=" text-gray-400"><strong>Facilities</strong></span> | <span class=" text-orange-500">
                    Analysis</span>
            </div>
        </template>
    </SharedBorderedNavBar>
    <!-- <pre>
{{ facilityEvalCounts }}
</pre> -->
    <UContainer class='py-10'>
        <div class=" flex gap-10">
            <div class="mt-2.5">Number of <span class="font-bold">Facilities</span>:</div>
            <div class="text-green-500 text-5xl"> {{ facilities.flat().length }} </div>
        </div>
        <UDivider class="py-5" />
        <div ref="facility mentees">
            <div class="font-bold pb-5 text-orange-500">Mentees by Facility:</div>
            <div class="grid grid-cols-4 gap-5 bg-gray-100 py-2.5 font-bold">
                <div class="">Facilities</div>
                <div class=" text-center">Mentees (Count)</div>
                <div class=" text-center">Mean Score</div>
                <div class=" text-center">View</div>

            </div>
            <div class="grid grid-cols-4 gap-5 border-t py-2.5" v-for="facility in facilityMenteeCounts">
                <div class="font-bold">
                    {{ facility.facility }}
                </div>
                <div class=" text-center">
                    <NuxtLink :to="{
                        name: Routes.REPORTING_FACILITY_STATUS.name,
                        params: {
                            facility: facility.facility,
                            status: 'all'
                        }
                    }">
                        <UButton variant="soft" size="sm" color="gray">
                            {{ facility.mentees }}
                        </UButton>
                    </NuxtLink>
                </div>
                <div class="text-center">
                    <span class="text-rose-500 font-bold"
                        v-if="parseFloat(countSessionsFacility(facility.facility).allCompletedMean) < 2.5">
                        {{ countSessionsFacility(facility.facility).allCompletedMean }}
                    </span>
                    <span class="text-sky-500 font-bold" v-else>
                        {{ countSessionsFacility(facility.facility).allCompletedMean }}
                    </span>

                </div>
                <div class="flex justify-center">
                    <NuxtLink :to="{
                        name: Routes.REPORTING_FACILITY_STATUS_REPORT.name,
                        params: {
                            facility: facility.facility,
                            status: 'all'
                        }
                    }">
                        <UButton variant="soft" size="sm" color="orange">
                            Report
                        </UButton>
                    </NuxtLink>
                </div>
            </div>
        </div>

        <UDivider class="py-5" label="Progress Tracking" />
        <div ref=''>
            <div class="font-bold pb-5 text-orange-500">Evaluation Completions:</div>
            <div class="grid grid-cols-5 gap-5 font-semibold text-zinc-500 text-sm  py-5 bg-green-50 ">
                <div class="text-center">
                    Facility
                </div>
                <div class="text-center">

                    Completed Evaluations
                </div>
                <div class="text-center">
                    <div>
                        Partially Completed
                    </div>
                    <div>
                        (2 Sessions)
                    </div>
                </div>
                <div class="text-center">
                    <div>
                        Partially Completed
                    </div>
                    <div>
                        (1 Session)
                    </div>
                </div>
                <div class="text-center">
                    Total Evaluations
                </div>
            </div>
            <div class="grid grid-cols-5 gap-5 hover:bg-gray-100 cursor-pointer py-2.5 border-t "
                v-for="facility in facilityEvalCounts">
                <div class="font-bold">
                    {{ facility.facility }}
                </div>
                <div class="text-center">
                    <NuxtLink :to="{
                        name: Routes.REPORTING_FACILITY_STATUS.name,
                        params: {
                            facility: facility.facility,
                            status: 'completed'
                        }
                    }">
                        <UButton variant="soft" size="sm" color="gray">
                            {{ facility.completedEvals }}
                        </UButton>
                    </NuxtLink>
                </div>
                <div class="text-center">
                    <NuxtLink :to="{
                        name: Routes.REPORTING_FACILITY_STATUS.name,
                        params: {
                            facility: facility.facility,
                            status: 'twocompleted'
                        }
                    }">
                        <UButton variant="soft" size="sm" color="gray">
                            {{ facility.twoCompletedEvals }}
                        </UButton>
                    </NuxtLink>
              
                </div>
                <div class="text-center">
                    <NuxtLink :to="{
                        name: Routes.REPORTING_FACILITY_STATUS.name,
                        params: {
                            facility: facility.facility,
                            status: 'onecompleted'
                        }
                    }">
                        <UButton variant="soft" size="sm" color="gray">
                            {{ facility.oneCompletedEvals }}
                        </UButton>
                    </NuxtLink>
                   
                </div>
                <div class="text-center text-blue-500 font-semibold">
                    {{ facility.totalEvals }}
                </div>
            </div>
        </div>
    </UContainer>

</template>