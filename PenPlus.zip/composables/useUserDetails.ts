import LocalStorageKeys from "@/constants/LocalStorageKeys";

//const useAuth = useAuthStore()
const user:any = useProcessLocalStorage().retrieve(LocalStorageKeys.PROFILE)

export default user