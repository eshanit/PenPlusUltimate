import type ISession from "./ISession";


interface FinalEvaluation {
    _id: string;
    evaluator: object;
    evaluationID: string;
    mentee: object;
    searchIndex: string;
    dateSaved: number;
    status: string;
    tool: string;
    sessions: Array<ISession>;
}

type IFinalEvaluation  = Readonly<FinalEvaluation>

export type { IFinalEvaluation  as default}