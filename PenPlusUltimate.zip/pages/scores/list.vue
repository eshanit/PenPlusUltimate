<script setup lang="ts">
import Routes from '@/constants/Routes';

const user = useUserDetails;
</script>
<template>
    <SharedBorderedNavBar>
        <template #lead>
            <NuxtLink :to="Routes.DASHBOARD.path">
                <div class="pr-5 text-blue-500 cursor-pointer">
                    <UIcon name="i-heroicons-arrow-small-left" />
                </div>
            </NuxtLink>
            <div>
                <span class=" text-gray-400"><strong>Completed Evaluations</strong></span> | <span class=" text-sky-700"> -</span>
            </div>
        </template>
    </SharedBorderedNavBar>
    <UContainer>
        <SharedTwCardWithHeader>
            <template #header>
                <span class=" font-semibold text-orange-500">List of evaluations by :</span> <span class=" text-teal-500">{{ user.firstname }} {{ user.lastname }}</span>
            </template>
            <template #body>
                <TablesEvaluations />
            </template>
        </SharedTwCardWithHeader>
    </UContainer>
</template>