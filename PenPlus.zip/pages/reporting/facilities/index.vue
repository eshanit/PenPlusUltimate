<script setup lang="ts">
import type IDistrict from "@/interfaces/IDistrict";
import Routes from '@/constants/Routes';
import DatabaseNames from "@/constants/DatabaseNames";
import { computedAsync } from "@vueuse/core";

const router = useRouter();

const goBack = () => {
    router.back();
};
//

const facilities: Ref<Array<string>> = ref([])

//districts
const useDistricts = useDistrictsStore();

const districts: Array<IDistrict> = await useDistricts.fetchDistricts();

districts?.forEach((d: any) => {
    facilities.value.push(d.facilities);
})

//stats
const facilityMenteeCounts: Ref<Array<any>> = ref([])
const facilityEvalCounts: Ref<Array<any>> = ref([])

// mentees
const useMentees = useMenteeStore()

const facilityMentees = async (facility: string) => {

    return await useMentees.fetchAllMentees(facility)

}
//
//evaluations
const useEvaluations = useEvalDataStore();

const completedEvals = await useEvaluations.fetchEvaluationScores(DatabaseNames.COMPLETED_EVALUTATIONS);

const evaluationStats = useEvaluationStats(completedEvals)

const countSessionsFacility = (facility: string) => {
    const allCompleted = evaluationStats.completedEvaluations.filter((el) => {
        return el.mentee.facility == facility
    })

    const twoCompleted = evaluationStats.completed2Evals.filter((el) => {
        return el.mentee.facility == facility
    })

    const oneCompleted = evaluationStats.completed1Evals.filter((el) => {
        return el.mentee.facility == facility
    })

    const allEvaluations = completedEvals.filter((el: any) => {
        return (el.mentee.facility == facility)
    })

    //means
    let allScores = [];
    allScores = allEvaluations.map((el: any) => {
        return el.sessions
    })

    let allSessions = [];
    allSessions = allScores.map((el: any) => {
        return [
            el.session_1?.evalItemScores,
            el.session_2?.evalItemScores,
            el.session_3?.evalItemScores
        ].flat(2).filter(item => item != null)
    })
    // console.log(Array.isArray(allSessions[0]));
    // Flatten the array and map scores to numbers
    const flattenedScores = allSessions.flat().map((item: any) => parseFloat(item.score));

    // Calculate the sum and count of scores
    const totalScore = flattenedScores.reduce((sum: any, score: any) => sum + score, 0);
    const count = flattenedScores.length;

    // Calculate the mean score
    const meanScore = count > 0 ? (totalScore / count).toFixed(2) : "0.00";

    return {
        allCompletedCount: allCompleted.length,
        twoCompletedCount: twoCompleted.length,
        oneCompletedCount: oneCompleted.length,
        // Means
        allCompletedMean: meanScore
    }
}

//
computedAsync(() => {
    const allPromises: any[] = [];

    facilities.value.flat().forEach((f: any) => allPromises.push(
        //

        facilityMentees(f).then((mentees) => {

            facilityMenteeCounts.value.push({
                facility: f,
                mentees: mentees?.length
            })

            //facility 
            facilityEvalCounts.value.push({
                facility: f,
                completedEvals: countSessionsFacility(f).allCompletedCount,
                twoCompletedEvals: countSessionsFacility(f).twoCompletedCount,
                oneCompletedEvals: countSessionsFacility(f).oneCompletedCount,
                totalEvals: countSessionsFacility(f).allCompletedCount +
                    countSessionsFacility(f).twoCompletedCount
                    + countSessionsFacility(f).oneCompletedCount
            })
        }),

        //
    ))


    Promise.all(allPromises)

})

const showFacilityChartPerc: Ref<Boolean> = ref(false)

</script>
<template>
    <SharedBorderedNavBar>
        <template #lead>
            <!-- <NuxtLink :to="Routes.COMPLETED_EVALUATIONS.path"> -->
            <div class="pr-5 text-blue-500 cursor-pointer" @click="goBack">
                <UIcon name="i-heroicons-arrow-small-left" />
            </div>
            <!-- </NuxtLink> -->
            <div>
                <span class=" text-gray-400"><strong>Facilities</strong></span> | <span class=" text-orange-500">
                    Analysis</span>
            </div>
        </template>
    </SharedBorderedNavBar>
    <!-- <pre>
{{ facilityEvalCounts }}
</pre> -->
    <UContainer class='py-10'>
        <div class=" flex gap-10">
            <div class="mt-2.5">Number of <span class="font-bold">Facilities</span>:</div>
            <div class="text-green-500 text-5xl"> {{ facilities.flat().length }} </div>
        </div>
        <UDivider class="py-5" />
        <div ref="facility mentees">
            <UCard>
                <template #header>
                    <div class="font-bold pb-5 text-sky-700">Mentees by Facility:</div>
                </template>
                <div class="pt-2.5 pb-5">
                    Table below shows the list of all facilities and the number of providers in each facility. Clicking the button containing the count will take you to the list of those providers.
                </div>
                <div class="grid grid-cols-4 gap-5 bg-gray-100 py-2.5 font-bold">
                    <div class="">Facilities</div>
                    <div class=" text-center">Mentees (Count)</div>
                    <div class=" text-center">Mean Score</div>
                    <div class=" text-center">View</div>

                </div>
                <div class="grid grid-cols-4 gap-5 border-t py-2.5" v-for="facility in facilityMenteeCounts">
                    <div class="font-bold">
                        {{ facility.facility }}
                    </div>
                    <div class=" text-center">
                        <NuxtLink :to="{
                            name: Routes.REPORTING_FACILITY_STATUS.name,
                            params: {
                                facility: facility.facility,
                                status: 'all'
                            }
                        }">
                            <UButton variant="soft" size="sm" color="gray">
                                {{ facility.mentees }}
                            </UButton>
                        </NuxtLink>
                    </div>
                    <div class="text-center">
                        <span class="text-rose-500 font-bold"
                            v-if="parseFloat(countSessionsFacility(facility.facility).allCompletedMean) < 2.5">
                            {{ countSessionsFacility(facility.facility).allCompletedMean }}
                        </span>
                        <span class="text-sky-500 font-bold" v-else>
                            {{ countSessionsFacility(facility.facility).allCompletedMean }}
                        </span>

                    </div>
                    <div class="flex justify-center">
                        <NuxtLink :to="{
                            name: Routes.REPORTING_FACILITY_STATUS_REPORT.name,
                            params: {
                                facility: facility.facility,
                                status: 'all'
                            }
                        }">
                            <UButton variant="soft" size="sm" color="orange">
                                Report
                            </UButton>
                        </NuxtLink>
                    </div>
                </div>
            </UCard>
        </div>

        <UDivider class="py-5" label="Progress Tracking" />
        <UCard class="bg-sky-50 pb-10">
            <template #header>
                <div class="font-bold pb-5 text-orange-500">Evaluations by Facility:</div>
            </template>
            <div class="text-sky-900">
                The charts below show the number of evaluation-sessions done for each <span
                    class="font-semibold">Facility</span>. Its broken down by number of evaluations with
                1 session, 2 sessions and 3 sessions. A completed evaluation is one with 3 sessions.
            </div>

            <div class="py-5">
                <div v-if="showFacilityChartPerc">
                    <div class="pb-2.5">
                        <UButton @click="showFacilityChartPerc = false">
                            View Counts
                            <template #trailing></template>
                        </UButton>
                    </div>
                    <ChartsDashboardFacilitiesStackedPerc :evaluation-stats="evaluationStats"
                        :facilities="facilities?.flat()" />

                </div>
                <div v-else>
                    <div class="pb-2.5">
                        <UButton @click="showFacilityChartPerc = true">
                            View Percentages
                        </UButton>
                    </div>
                    <ChartsDashboardFacilitiesStacked :evaluation-stats="evaluationStats"
                        :facilities="facilities?.flat()" />
                </div>
            </div>
            <TablesAGtablesDashboardFacilityEvaluations :evaluation-stats="evaluationStats"
                :facilities="facilities?.flat()" />
        </UCard>
        <div class="pb-10" />
    </UContainer>

</template>