interface Evaluation {
    evaluationID: string;
    tool: string;
    sessions: Record<string, any>; // Replace `any` with a more specific type if needed
  }
  
  interface Data {
    overallMeanScore: string;
    completedEvaluations: Evaluation[];
  }
  
  interface ToolSessionCount {
    [key: string]: number;
  }
  
  export function useMostSessionsTool(data: Data) {
    const toolSessionCount: ToolSessionCount = {};
  
    // Count sessions for each tool
    data.completedEvaluations.forEach(evaluation => {
      const tool = evaluation.tool;
      const sessionCount = Object.keys(evaluation.sessions).length;
  
      if (!toolSessionCount[tool]) {
        toolSessionCount[tool] = 0;
      }
      toolSessionCount[tool] += sessionCount;
    });
  
    // Find the tool with the most sessions
    let maxSessionsTool: string | null = null;
    let maxSessionsCount = 0;
  
    for (const [tool, count] of Object.entries(toolSessionCount)) {
      if (count > maxSessionsCount) {
        maxSessionsCount = count;
        maxSessionsTool = tool;
      }
    }
  
    return { tool: maxSessionsTool, count: maxSessionsCount };
  }