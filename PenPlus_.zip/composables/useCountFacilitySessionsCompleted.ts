
export function useCountFacilitySessionsCompleted(facility: string, evaluationStats: any) {

    const allCompleted = evaluationStats.completedEvaluations.filter((el: any) => {
        return el.mentee.facility == facility
    })

    const twoCompleted = evaluationStats.completed2Evals.filter((el: any) => {
        return el.mentee.facility == facility
    })

    const oneCompleted = evaluationStats.completed1Evals.filter((el: any) => {
        return el.mentee.facility == facility
    })



    return {
        allCompletedCount: allCompleted.length,
        twoCompletedCount: twoCompleted.length,
        oneCompletedCount: oneCompleted.length,
        totalCompletedCount: oneCompleted.length + twoCompleted.length + allCompleted.length,
        //sessions
        totalCompletedSessions: oneCompleted.length + (2*twoCompleted.length) + (3*allCompleted.length)
    }
}