<script setup lang='ts'>
import DatabaseNames from "@/constants/DatabaseNames";
import sumArray from "@/utilities/sumArray";
import type IDistrict from "@/interfaces/IDistrict";
import { computedAsync } from "@vueuse/core";
import type IEvalScore from "@/interfaces/IEvalScore";

const router = useRouter();

const goBack = () => {
    router.back();
};


//districts
const useDistricts = useDistrictsStore();

const districts: Array<IDistrict> = await useDistricts.fetchDistricts();



//evaluations
const useEvaluations = useEvalDataStore();

const completedEvals = await useEvaluations.fetchEvaluationScores(DatabaseNames.COMPLETED_EVALUTATIONS);

const evaluationStats = useEvaluationStats(completedEvals)

// mentees
const useMentees = useMenteeStore()

const facilityMentees = async (facility: string) => {

    return await useMentees.fetchAllMentees(facility)

}

const districtMentees = async (district: string) => {
    return await useMentees.fetchDistrictMentees(district)
}

const tools = useTools;
const facilities: Ref<Array<String>> = ref([])
const facilityEvalCounts: Ref<Array<any>> = ref([])
const facilityEvalToolCounts: Ref<Array<any>> = ref([])
const facilityMenteeCounts: Ref<Array<any>> = ref([])

computedAsync(() => {

    const allPromises: any[] = [];

    districts?.forEach((d: any) => {
        let facil = []
        facilities.value.push(d.facilities);
        facil.push(d.facilities);

        facil.forEach((f) => {

            f.forEach((el: string) => {

                allPromises.push(
                    // Mentees
                    facilityMentees(el).then((mentees) => {
                        facilityMenteeCounts.value.push({
                            district: d.district,
                            facility: el,
                            mentees: mentees?.length
                        })
                    }),

                    //facility 
                    facilityEvalCounts.value.push({
                        district: d.district,
                        facility: el,
                        completedEvals: useCountFacilitySessionsCompleted(el, evaluationStats).allCompletedCount,
                        fourCompletedEvals: useCountFacilitySessionsCompleted(el, evaluationStats).fourCompletedCount,
                        threeCompletedEvals: useCountFacilitySessionsCompleted(el, evaluationStats).threeCompletedCount,
                        twoCompletedEvals: useCountFacilitySessionsCompleted(el, evaluationStats).twoCompletedCount,
                        oneCompletedEvals: useCountFacilitySessionsCompleted(el, evaluationStats).oneCompletedCount,
                        totalEvals: useCountFacilitySessionsCompleted(el, evaluationStats).totalCompletedCount
                    }),
                    //tools

                    tools.forEach((t) => {
                        facilityEvalToolCounts.value.push({
                            district: d.district,
                            facility: el,
                            tool: t.name,
                            completedEvals: useCountFacilityToolSessionsCompleted(el, t.name, evaluationStats).allCompletedCount,
                            fourCompletedEvals: useCountFacilityToolSessionsCompleted(el, t.name, evaluationStats).fourCompletedCount,
                            threeCompletedEvals: useCountFacilityToolSessionsCompleted(el, t.name, evaluationStats).threeCompletedCount,
                            twoCompletedEvals: useCountFacilityToolSessionsCompleted(el, t.name, evaluationStats).twoCompletedCount,
                            oneCompletedEvals: useCountFacilityToolSessionsCompleted(el, t.name, evaluationStats).oneCompletedCount,
                            totalEvals: useCountFacilityToolSessionsCompleted(el, t.name, evaluationStats).totalCompletedCount
                        })
                    })
                    //


                )
            })
        })
    })

    Promise.all(allPromises)
})


const filterDistrictEvals = (district: string) => {
    return facilityEvalCounts.value.filter(f => f.district === district)
}

//filter by district and Tool

const filterToolDistrictEvals = (district: string, tool: string) => {
    return facilityEvalToolCounts.value.filter(f => (f.district == district && f.tool == tool))
}

//filter Mentees by District
const filterDistrictMentees = (district: string) => {
    // loadMenteeCounts()
    return facilityMenteeCounts.value.filter(f => f.district == district)
}

//
const viewDistrictAnalysis = (district: string): void => {

    navigateTo(`districts/${district}`)
}

const viewDistrictMentees = (district: string): void => {

    navigateTo(`districts/${district}/mentees`)
}

const viewDistrictEvaluations = (district: string): void => {

navigateTo(`districts/${district}/evaluations`)

}

const viewDistrictFacilityEvaluations = (district: string, facility: string): void => {

navigateTo(`districts/${district}/${facility}/evaluations`)

}

const viewFacilityReport = (facility: string): void => {

navigateTo(`facilities/${facility}/all`)

}


///

const viewCompletedEvals = (district: string): void => {

navigateTo(`districts/${district}/completed`)

}

const viewTwoCompletedEvals = (district: string): void => {

navigateTo(`districts/${district}/twocompleted`)

}

const viewOneCompletedEvals = (district: string): void => {

navigateTo(`districts/${district}/onecompleted`)

}

const viewAllEvals = (district: string): void => {

navigateTo(`districts/${district}/all`)

}


const viewDistrictTool = (district :string, tool: string) => {
    navigateTo(`districts/${district}/Tools/${tool}`)
}
</script>
<template>
    <SharedBorderedNavBar>
        <template #lead>
            <!-- <NuxtLink :to="Routes.COMPLETED_EVALUATIONS.path"> -->
            <div class="pr-5 text-blue-500 cursor-pointer" @click="goBack">
                <UIcon name="i-heroicons-arrow-small-left" />
            </div>
            <!-- </NuxtLink> -->
            <div>
                <span class=" text-gray-400"><strong>Districts</strong></span> | <span class=" text-orange-500">
                    Analysis</span>
            </div>
        </template>
    </SharedBorderedNavBar>

    <UContainer class='py-10'>
        <div class=" flex gap-10">
            <div>Number of Districts:</div>
            <div class="text-green-500 text-5xl"> {{ districts.length }} </div>
        </div>
        <UDivider class="py-5" />
        <UCard ref="district mentees" class="">
            <template #header>
                <div class="font-bold pb-5 text-sky-700">Mentees by District:</div>
            </template>
            <div class="pt-2.5 pb-5">
                Below is a table which shows the list of districts for which evaluations were done. Each district has its providers counted, if you click on the number of mentees you will be taken
                to a page which lists the providers in that district. If you click on the green view button, you will see the summary report on important metrics for that particular district.
            </div>
           
            <div class="grid grid-cols-4 gap-5 bg-gray-100 p-2.5 font-bold">
                <div>District</div>
                <div class="text-center">Facilities (Count)</div>
                <div class="text-center">Mentees (Count)</div>
                <div class="text-center">Report</div>
            </div>
            <div class="grid grid-cols-4 gap-5 border-t p-2.5" v-for="district in districts">
                <div class="font-bold">
                    {{ district.district }}
                </div>
                <div class="flex justify-center">
                   
                    <UPopover mode="hover">
                        <span class="text-sky-600 font-semibold underline decoration-dotted">  {{ district.facilities.length }}
                        </span>
                        <template #panel>
                            <div class="bg-sky-50 text-left grid grid-cols-3 gap-5 py-1.5" v-for="facility in district.facilities">
                                <div></div>
                                <div>
                                    {{ facility }}
                                </div>
                                <div></div>
                            </div>
                        </template>
                    </UPopover>
                </div>
                <div class="text-center">
                    <UButton variant="soft" size="sm" color="gray" @click="viewDistrictMentees(district.district)">
                        {{ sumArray(filterDistrictMentees(district.district), 'mentees') }}
                    </UButton>
                </div>
                <div class="text-center">
                    <UButton variant="soft" size="sm" @click="viewDistrictAnalysis(district.district)">
                        View
                    </UButton>
                </div>
            </div>

        </UCard>
        <!-- <pre>
        {{ countSessionsFacility("Bere") }}
    </pre> -->
        <UDivider class="py-5" label="Evaluations Breakdown" />

        <UCard ref='' class="">
            <template #header>
                <div class="font-bold pb-5 text-sky-700">Evaluations by District -> Facilities:</div>
            </template>
            <div class="pt-2.5 pb-5">
               This table breaks down each district by its facilities, now one can see how many evaluations were done in each facility and also in each district. Clicking on the buttons will take you to further insights on 
               the values. The mean score is the average score a facility within a district across all disease/tool evaluations.
            </div>
           
            
            <div class="grid grid-cols-3 gap-5 bg-gray-100 p-2.5 font-bold">
                <div>District</div>
                <div class="">
                    <div class=" grid grid-cols-3 gap-5">
                        <div>Facility</div>
                        <div>Evaluations</div>
                        <div>Mean Score</div>
                    </div>
                </div>
                <div class="text-center">District evals</div>

            </div>
            <div class="grid grid-cols-3 gap-5 border-t p-2.5" v-for="district in districts">
                <div class="font-bold">
                    {{ district.district }}
                </div>
                <div ref="facilities">
                    <div class=" grid grid-cols-3 gap-5 py-1.5" v-for="facility in district.facilities">
                        <div>
                            {{ facility }}
                        </div>
                        <div>
                            
                            <UButton variant="soft" size="sm" color="gray" @click="viewDistrictFacilityEvaluations(district.district, facility)">
                                {{ useCountFacilitySessionsCompleted(facility, evaluationStats).totalCompletedCount }}
                            </UButton>
                           
                        </div>
                        <div class="">
                            <span class="text-rose-500 font-bold"
                                v-if="parseFloat(useFacilityMeans(completedEvals, facility)) < 2.5">
                                <UButton variant="soft" size="sm" color="rose" @click="viewFacilityReport(facility)">
                                    {{ useFacilityMeans(completedEvals, facility) }}
                                </UButton>
                            </span>
                            <span class="text-sky-500 font-bold" v-else>
                                <UButton variant="soft" size="sm" color="sky" @click="viewFacilityReport(facility)">
                                    {{ useFacilityMeans(completedEvals, facility) }}
                                </UButton>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="flex items-center justify-center text-3xl">
                    <UButton variant="soft" size="sm" color="sky" @click="viewDistrictEvaluations(district.district)">
                        {{ sumArray(filterDistrictEvals(district.district), 'totalEvals') }}
                    </UButton>
                </div>
            </div>
        </UCard>
        <UDivider label="District Progress Tracking" class="py-10" />
        <UCard ref=''>
            <template #header>
                <div class="font-bold text-sky-700 pb-5">Evaluation Completions:</div>
            </template>
            <div class="pt-2.5 pb-5">
               Here we are tracking evaluations done in each district. We have the number of evaluations which where completed (i.e all 5 sessions done for a provider on a disease), we also track 
               incomplete evaluations (i.e those providers with 1, 2, 3, or 4 sessions per tool). To see those providers and their corresponding evaluation sessions you can click the buttons in the cells.
            </div>
            
            <div class="grid grid-cols-7 gap-5 font-semibold text-zinc-500 text-sm  py-5 bg-green-50 ">
                <div class="text-center">
                    District
                </div>   
                <div class="text-center">
                    <div>
                        Partially Completed
                    </div>
                    <div>
                        (1 Session)
                    </div>
                </div>
                <div class="text-center">
                    <div>
                        Partially Completed
                    </div>
                    <div>
                        (2 Sessions)
                    </div>
                </div>
                <div class="text-center">
                    <div>
                        Partially Completed
                    </div>
                    <div>
                        (3 Sessions)
                    </div>
                </div>
                <div class="text-center">
                    <div>
                        Partially Completed
                    </div>
                    <div>
                        (4 Sessions)
                    </div>
                </div>
                <div class="text-center">
                    <div>
                        Completed Evaluations
                    </div>
                    <div>
                        (5 Sessions)
                    </div>
                </div>
                <div class="text-center">
                    Total Evaluations
                </div>
            </div>
            <div class="grid grid-cols-7 gap-5 hover:bg-gray-100 cursor-pointer p-2.5 border-t "
                v-for="district in districts">
                <div class="font-bold">
                    {{ district.district }}
                </div>
                <div class="text-center">
                    <UButton color="red" variant="soft" @click="viewOneCompletedEvals(district.district )" >
                     {{ sumArray(filterDistrictEvals(district.district), 'oneCompletedEvals') }}
                    </UButton>
                </div>
                <div class="text-center">
                   
                   <UButton color="orange" variant="soft" @click="viewTwoCompletedEvals(district.district )" >
                       {{ sumArray(filterDistrictEvals(district.district), 'twoCompletedEvals') }}
                   </UButton>
               </div>
               <div class="text-center">
                   <UButton color="yellow" variant="soft" @click="viewOneCompletedEvals(district.district )" >
                    {{ sumArray(filterDistrictEvals(district.district), 'threeCompletedEvals') }}
                   </UButton>
               </div>
               <div class="text-center">
                   
                   <UButton color="lime" variant="soft" @click="viewTwoCompletedEvals(district.district )" >
                       {{ sumArray(filterDistrictEvals(district.district), 'fourCompletedEvals') }}
                   </UButton>
               </div>
                <div class="text-center">
                    <UButton color="green" variant="soft" @click="viewCompletedEvals(district.district )" >
                        {{ sumArray(filterDistrictEvals(district.district), 'completedEvals') }}
                    </UButton>
                </div> 
                <div class="text-center text-blue-500 font-semibold">
                    <UButton color="sky" variant="soft" @click="viewAllEvals(district.district )" >
                    {{ sumArray(filterDistrictEvals(district.district), 'totalEvals') }}
                    </UButton>
                </div>
            </div>
        </UCard>
        <div class="py-2.5" />
        <UCard ref="District Tools">
           <template #header>
                <div class="font-bold text-sky-700 pb-5">Tool Evaluations by District:</div>
           </template>
           <div class="pt-2.5 pb-5">
               Here we are tracking evaluations done for each tool/disease within each district. We have the number of evaluations which where completed (i.e all 5 sessions done for a provider on a disease), we also track 
               incomplete evaluations (i.e those providers with 1, 2, 3, or 4 sessions per tool). To see those providers and their corresponding evaluation sessions you can click the buttons in the cells.
            </div>
            <div class="grid grid-cols-5 gap-5 font-semibold text-zinc-500 text-sm  py-5 bg-zinc-50 ">
                <div class="text-center">
                    Tool/District
                </div>
                <div class="text-center" v-for="district in districts">
                    {{ district.district }}
                </div>
            </div>
          
            <div class="grid grid-cols-5 gap-5 hover:bg-gray-100 cursor-pointer p-2.5 border-t "
                v-for="(tool, i) in tools">
                <div class="font-bold">
                    {{ tool.label }}
                </div>
                <div class="text-center" v-for="district in districts">
                    <UButton color="green" variant="soft" @click="viewDistrictTool(district.district, tool.name )" >
                         {{ sumArray(filterToolDistrictEvals(district.district, tool.name), 'totalEvals') }}
                    </UButton>
                </div>
            </div>
        </UCard>
    </UContainer>
</template>