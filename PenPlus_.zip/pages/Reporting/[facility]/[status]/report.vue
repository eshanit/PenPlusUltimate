<script setup lang="ts">
import { ref, watch, onMounted } from 'vue';
import { useRoute, useRouter, onBeforeRouteUpdate } from 'vue-router';
import DatabaseNames from "@/constants/DatabaseNames";
import capitalizeFirstLetter from "@/utilities/capitalizeFirstLetter";
import evaluationItemData from '~/data/evaluationItemData';


const route = useRoute();
const router = useRouter();
const facility = route.params.facility
const status = route.params.status

const showTool = ref(false);
const completedEvals: any = ref([]);

const useEvaluations = useEvalDataStore();

// Fetch data on component mount
onMounted(async () => {
    console.log('Component mounted, fetching data...');
    completedEvals.value = await useEvaluations.fetchEvaluationScores(DatabaseNames.COMPLETED_EVALUTATIONS);
    console.log('Data fetched:', completedEvals.value);
});

// Watch for route changes
watch(
    () => route.params,
    async (newParams) => {
        console.log('Route params changed:', newParams);
        completedEvals.value = await useEvaluations.fetchEvaluationScores(DatabaseNames.COMPLETED_EVALUTATIONS);
        console.log('Data fetched:', completedEvals.value);
    },
    { immediate: true }
);

// Handle route updates
onBeforeRouteUpdate(async (to, from, next) => {
    console.log('Route updated, fetching data...');
    completedEvals.value = await useEvaluations.fetchEvaluationScores(DatabaseNames.COMPLETED_EVALUTATIONS);
    next();
});

const goBack = () => {
    router.back();
};



const toolsEvals = computed(() => {
    const evaluationStats = useEvaluationStats(completedEvals.value);

    let evals;

    if (status == 'completed') {
        evals = evaluationStats.completedEvaluations.filter((el) => el.mentee.facility == facility);
    } else if (status == 'twocompleted') {
        evals = evaluationStats.completed2Evals.filter((el) => el.mentee.facility == facility);
    } else if (status == 'onecompleted') {
        evals = evaluationStats.completed1Evals.filter((el) => el.mentee.facility == facility);
    } else {
        evals = completedEvals.value.filter((el: any) => el.mentee.facility == facility);
    }

    return evals;
});

const ImprovementsToolCount = computed(() => {
    const dataArray = useImprovementsPerTool(toolsEvals.value);
    return dataArray.reduce((acc: { [key: string]: number }, item) => {
        if (item.improvement == true) {
            acc[item.tool] = (acc[item.tool] || 0) + 1;
        }
        return acc;
    }, {} as { [key: string]: number }); // Type assertion for the initial value
});


const itemsCount = (items: {}) => {
    return Object.keys(items).length;
};

const toolTitle = (code: string) => {
    for (const tool of evaluationItemData) {
        for (const item of tool.evaluationItems) {
            if (item.number === code) {
                return item.title;
            }
        }
    }
    return null;
}

const mentees = computed(() => {
    const menteesArray = toolsEvals.value.map((tool: { mentee: { _id: any; }; }) => tool.mentee._id)

    return [...new Set(menteesArray)]
})

const percent = (num: number) => {
    return (100*num/mentees.value.length).toFixed(2);
}

</script>

<template>

    <div :key="route.fullPath">
        <div v-if="completedEvals && completedEvals.length > 0">
            <SharedBorderedNavBar>
                <template #lead>
                    <div v-show="!showTool">
                        <div class="pr-5 text-blue-500 cursor-pointer" @click="goBack">
                            <UIcon name="i-heroicons-arrow-small-left" />
                            Back
                        </div>
                    </div>
                    <div v-show="showTool">
                        <div class="pr-5 text-blue-500 cursor-pointer" @click="showTool = false">
                            <UIcon name="i-heroicons-arrow-small-left" />
                        </div>
                    </div>
                </template>
            </SharedBorderedNavBar>
            <UContainer>
                <div>
                    <div class="text-red-700 text-3xl py-2.5">{{ facility }}</div>
                    <UDivider class="py-5" label="Knowledge Improvement" />

                    <div>There are <span class=" text-orange-500 font-bold"> {{
                        Object.keys(ImprovementsToolCount).length }} </span>
                        tools with improvements , below is the breakdown: </div>
                    <div class="pb-5 ">
                        <div v-for="tool in Object.keys(ImprovementsToolCount)">
                            <div class="flex">
                                <div class="py-0.5 text-green-500">
                                    <UIcon name="i-heroicons-chevron-right" />
                                </div>
                                <div><span class="text-sky-700 font-bold">{{ capitalizeFirstLetter(tool) }}</span> has
                                    {{
                                        ImprovementsToolCount[tool] }} <span
                                        v-if="ImprovementsToolCount[tool] <= 1">improvement</span><span
                                        v-else>improvements</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="border p-5 rounded-lg">
                        <div class="pb-5">Table showing Improvement Status </div>
                        <div class="grid grid-cols-3 gap-5 text-sky-700 font-bold">
                            <div>
                                Tool
                            </div>
                            <div>
                                Mentee
                            </div>
                            <div>
                                Status
                            </div>
                        </div>
                        <div class="grid grid-cols-3 gap-5 border-t py-2.5 hover:bg-gray-100 cursor-pointer"
                            v-for="status in useImprovementsPerTool(toolsEvals)">
                            <div>
                                {{ capitalizeFirstLetter(status.tool) }}
                            </div>
                            <div>
                                {{ status.mentee }}
                            </div>
                            <div>
                                <span v-if="status.improvement == true">
                                    <UBadge color="sky" variant="soft">Improved</UBadge>
                                </span>
                                <span v-if="status.improvement == false">
                                    <UBadge color="rose" variant="soft">Regressed</UBadge>
                                </span>
                                <span v-if="status.improvement == '-'">
                                    <UBadge color="gray" variant="soft">N/A</UBadge>
                                </span>
                                <span v-if="status.improvement == 'Max Score'">
                                    <UBadge color="green" variant="soft">'Maximum Score'</UBadge>
                                </span>
                            </div>
                        </div>

                    </div>
                </div>

                <UDivider label="Competency Responses" class="py-10" />
                <!-- <pre>
                    {{ mentees }}
                    {{ toolsEvals }}
                </pre> -->
                <div class="overflow-x-auto">
                    <table class="min-w-full border-collapse border border-gray-300">
                        <thead>
                            <tr class="bg-gray-200">
                                <th class="border border-gray-300 px-4 py-2">Tool/Disease</th>
                                <th class="border border-gray-300 px-4 py-2">Competency</th>
                                <th class="border border-gray-300 px-4 py-2">Ones</th>
                                <th class="border border-gray-300 px-4 py-2">Twos</th>
                                <th class="border border-gray-300 px-4 py-2">Threes</th>
                            </tr>
                        </thead>
                        <tbody>
                            <template v-for="(items, category) in useNumResponsesPerTool(toolsEvals)" :key="category">
                                <template v-for="(item, itemKey, index) in items">
                                    <tr>
                                        <td class="border border-gray-300 px-4 py-2 text-sky-700 font-bold" v-if="index === 0"
                                            :rowspan="itemsCount(items)">
                                            {{ capitalizeFirstLetter(category) }}
                                        </td>

                                        <td class="border border-gray-300 px-4 py-2">
                                            <UPopover mode="hover" >
                                                <div class=" font-semibold"> {{ itemKey }} </div>

                                                <template #panel>
                                                    <div class="p-4 bg-sky-200">
                                                        {{ toolTitle(itemKey.toString()) }}
                                                    </div>
                                                </template>
                                            </UPopover>
                                        </td>

                                        <td class="border border-gray-300 px-4 py-2">
                                            <div class="flex gap-1">
                                                <div>
                                                    {{ item.ones }} 
                                                </div>
                                                <div class="text-sky-700 italic">
                                                    ({{ percent(item.ones) }}%)
                                                </div>
                                            </div>
                                        
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2">
                                            <div class="flex gap-1">
                                                <div>
                                                    {{ item.twos }} 
                                                </div>
                                                <div class="text-sky-700 italic">
                                                    ({{ percent(item.twos) }}%)
                                                </div>
                                            </div>
                                        </td>
                                        <td class="border border-gray-300 px-4 py-2">
                                            <div class="flex gap-1">
                                                <div>
                                                    {{ item.threes }} 
                                                </div>
                                                <div class="text-sky-700 italic">
                                                    ({{ percent(item.threes) }}%)
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </template>
                            </template>
                        </tbody>
                    </table>
                </div>
                <div class="py-10" />
            </UContainer>
        </div>
        <div v-else>
            Loading...
        </div>
    </div>
</template>