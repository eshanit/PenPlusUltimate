import { Title } from "#build/components"

const INDEX = {
    path: '/',
    title: 'Home'
}

const LOGIN = {
    path: '/login',
    name: 'login',
    title: 'Login'
}

const REGISTRATION = {
    path: '/register',
    name: 'register',
    title: 'Register'
}

const DASHBOARD = {
    path: '/dashboard',
    name: 'dashboard',
    title: 'Dashboard'
}

const START_EVALUATION = {
    path: '/startEvaluating',
    name: 'startEvaluating',
    title: 'Start Evaluation'
}

const DISTRICTS = {
    path: '/planning/districts/list',
    name: 'planning-districts-list',
    title: 'Planning Districts'
}



const FACILITIES = {
    path: '/planning/facilities/list',
    name: 'planning-facilities-list',
    title: 'Planning_Facilities'
}

const MENTEES = {
    path: '/planning/mentees/list',
    name: 'planning-mentees-list',
    title: 'Planning Mentees'
}




const PREVIEW = {
    path: '/planning/preview',
    name: 'planning-preview-index',
    title: 'Preview'
}

const UPDATE_MENTEE = {
    path: '/planning/mentees/update',
    name: 'planning-mentees-update',
    title: 'Update Mentee'
}

const CREATE_MENTEE = {
    path: '/planning/mentees/create',
    name: 'planning-mentees-create',
    title: 'Create Mentee'
}


const EVALUATION_TOOL = {
    path: '/evaluation/tool',
    name: 'evaluation-tool',
    title: 'Evaluation Tool'
}

const EVALUATION_SUMMARY = {
    path: '/evaluation/tool/preview',
    name: 'evaluation-tool-preview',
    title: 'Evaluation Tool Preview'
}

const EVALUATION_ECHO_SUMMARY = {
    path: '/evaluation/tool/preview_echo',
    name: 'evaluation-tool-preview_echo',
    title: 'Evaluation Tool Echo Preview'
}

const SCORE_SUBMIT_SUCCESS = {
    path: '/evaluation/tool/success',
    name: 'evaluation-tool-success',
    title: 'Evaluation Tool Preview'
}

const CARDIAC_PRAC_EVALUATION = {
    path: '/evaluation/tool/cardiac',
    name: 'evaluation-tool-cardiac',
    title: 'Evaluation Tool Cardiac'
}


const ECHO_PRAC_EVALUATION = {
    path: '/evaluation/tool/echo',
    name: 'evaluation-tool-echo',
    title: 'Evaluation Tool Echo'
}

const SCORE = {
    path: '/scores/id',
    name: 'scores-id',
    title: 'Evaluation Score'
}



const COMPLETED_EVALUATIONS = {
    path: '/scores/list',
    name: 'scores-list',
    title: 'Evaluation Scores'
}


const FULL_EVALUATION_REPORT = {
    path: '/reports/full/id',
    name: 'reports-full-id',
    title: 'Evaluation Full Report'
}

//Repoting
const MENTEES_REPORTING = {
    path: 'Reporting/mentees',
    name: 'reporting-mentees',
    title: 'mentees'
}

const TOOLS_REPORTING = {
    path: 'Reporting/tools',
    name: 'reporting-tools',
    title: 'Reporting Tools'
}

const DISTRICTS_REPORTING = {
    path: 'Reporting/districts',
    name: 'reporting-districts',
    title: 'districts'
}

const DISTRICT_MENTEES_REPORTING = {
    path: 'Reporting/districts/district/mentees',
    name: 'reporting-districts-distrct-mentees',
    title: 'district mentees'
}

const DISTRICT_ANALYSIS  =  {
    path: 'Reporting/districts/district',
    name: 'reporting-districts-district',
    title: 'district '
}


const FACILITIES_REPORTING = {
    path: 'Reporting/facilities',
    name: 'reporting-facilities',
    title: 'reports facilities'
}

const REPORTING_TOOL_STATUS = {
    path: '/reporting/tool/status/indexTest',
    name: 'reporting-tool-status-indexTest',
    title: 'Evaluation Tool Status'
}

const REPORTING_FACILITY_STATUS = {
    path: '/reporting/facilities/facility/status',
    name: 'reporting-facilities-facility-status',
    title: 'Evaluation Facility Status'
}


const REPORTING_FACILITY_STATUS_REPORT = {
    path: '/reporting/facilities/facility/status/report',
    name: 'reporting-facilities-facility-status-report',
    title: 'Evaluation Facility Status Report'
}
export default {
    INDEX,
    LOGIN,
    REGISTRATION,
    DASHBOARD,
    DISTRICTS,
    FACILITIES,
    MENTEES,
    PREVIEW,
    CREATE_MENTEE,
    UPDATE_MENTEE,
    EVALUATION_TOOL,
    EVALUATION_SUMMARY,
    SCORE_SUBMIT_SUCCESS,
    CARDIAC_PRAC_EVALUATION,
    SCORE,
    COMPLETED_EVALUATIONS,
    START_EVALUATION,
    ECHO_PRAC_EVALUATION,
    EVALUATION_ECHO_SUMMARY,
    FULL_EVALUATION_REPORT,
    // reporting
    DISTRICTS_REPORTING,
    DISTRICT_MENTEES_REPORTING,
    DISTRICT_ANALYSIS,
    FACILITIES_REPORTING,
    REPORTING_TOOL_STATUS,
    REPORTING_FACILITY_STATUS,
    MENTEES_REPORTING,
    TOOLS_REPORTING,
    REPORTING_FACILITY_STATUS_REPORT
}