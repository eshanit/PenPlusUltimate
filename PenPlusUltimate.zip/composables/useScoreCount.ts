import type IEvalScore from "@/interfaces/IEvalScore";
import type IFinalEvaluation from '~/interfaces/IFinalEvaluation';

interface ScoreCount {
    [key: string]: number; // Dynamic keys for score counts
}

export function useScoreCount(data: IEvalScore[]) {
    const scoreCount = ref<ScoreCount>({});

    // Function to count the scores
    const countScores = () => {
        // Clear previous counts
        scoreCount.value = {};

        data.forEach(item => {
            const score = item.score;
            if (scoreCount.value[score]) {
                scoreCount.value[score]++;
            } else {
                scoreCount.value[score] = 1;
            }
        });
    };

    // Call the function to initialize count
    countScores();

    return scoreCount

}