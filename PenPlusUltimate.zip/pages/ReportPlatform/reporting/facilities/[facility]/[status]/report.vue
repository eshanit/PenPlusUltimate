<script setup lang="ts">
import { ref, watch, onMounted } from 'vue';
import { useRoute, useRouter, onBeforeRouteUpdate } from 'vue-router';
import DatabaseNames from "@/constants/DatabaseNames";
import capitalizeFirstLetter from "@/utilities/capitalizeFirstLetter";



const route = useRoute();
const router = useRouter();
const facility = route.params.facility
const status = route.params.status

const showTool = ref(false);
const completedEvals: any = ref([]);

const useEvaluations = useEvalDataStore();

// Fetch data on component mount
onMounted(async () => {
    console.log('Component mounted, fetching data...');
    completedEvals.value = await useEvaluations.fetchEvaluationScores(DatabaseNames.COMPLETED_EVALUTATIONS);
    console.log('Data fetched:', completedEvals.value);
});

// Watch for route changes
watch(
    () => route.params,
    async (newParams) => {
        console.log('Route params changed:', newParams);
        completedEvals.value = await useEvaluations.fetchEvaluationScores(DatabaseNames.COMPLETED_EVALUTATIONS);
        console.log('Data fetched:', completedEvals.value);
    },
    { immediate: true }
);

// Handle route updates
onBeforeRouteUpdate(async (to, from, next) => {
    console.log('Route updated, fetching data...');
    completedEvals.value = await useEvaluations.fetchEvaluationScores(DatabaseNames.COMPLETED_EVALUTATIONS);
    next();
});

const goBack = () => {
    router.back();
};



const toolsEvals = computed(() => {
    const evaluationStats = useEvaluationStats(completedEvals.value);

    let evals;

    if (status == 'completed') {
        evals = evaluationStats.completedEvaluations.filter((el) => el.mentee.facility == facility);
    } else if (status == 'twocompleted') {
        evals = evaluationStats.completed2Evals.filter((el) => el.mentee.facility == facility);
    } else if (status == 'onecompleted') {
        evals = evaluationStats.completed1Evals.filter((el) => el.mentee.facility == facility);
    } else {
        evals = completedEvals.value.filter((el: any) => el.mentee.facility == facility);
    }

    return evals;
});

const ImprovementsToolCount = computed(() => {
    const dataArray = useImprovementsPerTool(toolsEvals.value);
    return dataArray.reduce((acc: { [key: string]: number }, item) => {
        if (item.improvement == true) {
            acc[item.tool] = (acc[item.tool] || 0) + 1;
        }
        return acc;
    }, {} as { [key: string]: number }); // Type assertion for the initial value
});


//

const useMentees = useMenteeStore();

const countMentees = await useMentees.fetchAllMentees(facility)

//

const showAggregateTable: Ref<Boolean> = ref(true)


</script>

<template>

    <div :key="route.fullPath">
        <div v-if="completedEvals && completedEvals.length > 0">
            <SharedBorderedNavBar>
                <template #lead>
                    <div v-show="!showTool">
                        <div class="pr-5 text-blue-500 cursor-pointer" @click="goBack">
                            <UIcon name="i-heroicons-arrow-small-left" />
                            Back
                        </div>
                    </div>
                    <div v-show="showTool">
                        <div class="pr-5 text-blue-500 cursor-pointer" @click="showTool = false">
                            <UIcon name="i-heroicons-arrow-small-left" />
                        </div>
                    </div>
                </template>
            </SharedBorderedNavBar>
            <UContainer>
                <div>
                    <div class="text-red-700 text-3xl py-2.5">
                        <span>{{ facility }}</span>
                    </div>
                    <UDivider class="py-5" label="Knowledge Improvement" />

                    <div>There are <span class=" text-orange-500 font-bold"> {{
                        Object.keys(ImprovementsToolCount).length }} </span>
                        tools with improvements , below is the breakdown: </div>
                    <div class="pb-5 ">
                        <div v-for="tool in Object.keys(ImprovementsToolCount)">
                            <div class="flex">
                                <div class="py-0.5 text-green-500">
                                    <UIcon name="i-heroicons-chevron-right" />
                                </div>
                                <div><span class="text-sky-700 font-bold">{{ capitalizeFirstLetter(tool) }}</span> has
                                    {{
                                        ImprovementsToolCount[tool] }} <span
                                        v-if="ImprovementsToolCount[tool] <= 1">improvement</span><span
                                        v-else>improvements</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="border p-5 rounded-lg">
                        <div class="pb-5">Table showing Improvement Status </div>
                        <div class="grid grid-cols-3 gap-5 text-sky-700 font-bold">
                            <div>
                                Tool
                            </div>
                            <div>
                                Mentee
                            </div>
                            <div>
                                Status
                            </div>
                        </div>
                        <div class="grid grid-cols-3 gap-5 border-t py-2.5 hover:bg-gray-100 cursor-pointer"
                            v-for="status in useImprovementsPerTool(toolsEvals)">
                            <div>
                                {{ capitalizeFirstLetter(status.tool) }}
                            </div>
                            <div>
                                {{ status.mentee }}
                            </div>
                            <div>
                                <span v-if="status.improvement == true">
                                    <UBadge color="sky" variant="soft">Improved</UBadge>
                                </span>
                                <span v-if="status.improvement == false">
                                    <UBadge color="rose" variant="soft">Regressed</UBadge>
                                </span>
                                <span v-if="status.improvement == '-'">
                                    <UBadge color="gray" variant="soft">N/A</UBadge>
                                </span>
                                <span v-if="status.improvement == 'Max Score'">
                                    <UBadge color="green" variant="soft">'Maximum Score'</UBadge>
                                </span>
                            </div>
                        </div>

                    </div>
                </div>

                <UDivider label="Competency Response Count" class="py-10" />


                <div v-if="showAggregateTable">
                    <div>
                        <p class="pb-1.5">
                            The table below shows the number of scores per disease evaluated on. To see a comprehensive
                            breakdown by
                            each
                            evaluation item, click this button below:

                        </p>

                        <div>
                            <UButton label="View Itemized" @click="showAggregateTable = false" />
                        </div>
                    </div>
                    <div class="py-2.5" />
                    <TablesAggregateToolScoreCounts :tool-evals="toolsEvals" :mentees="countMentees.length" />
                </div>
                <div v-else>
                    <div>
                        <p class="pb-1.5">
                            The table below shows the number of scores per disease evaluated on. To see a summarized
                            breakdown , click this button below:

                        </p>

                        <div>
                            <UButton label="View Summarized" color="sky" @click="showAggregateTable = true" />
                        </div>
                    </div>
                    <div class="py-2.5" />
                    <TablesToolScoreCounts :tool-evals="toolsEvals" :mentees="countMentees.length" />

                </div>




                <div class="py-10" />
            </UContainer>
        </div>
        <div v-else>
            Loading...
        </div>
    </div>
</template>