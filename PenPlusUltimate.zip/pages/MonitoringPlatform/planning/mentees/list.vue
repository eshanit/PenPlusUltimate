<script setup lang="ts">
import Routes from "@/constants/Routes";
import LocalStorageKeys from "@/constants/LocalStorageKeys";


const showMenteeForm = ref(false)
const showUserUpdateForm = ref(false)
const showAlert = ref(false)
const menteeData = ref()
const useMentees = useMenteeStore()
//await useMentees.fetchAllMentees()
const selectedMentee: any = localStorage.getItem(LocalStorageKeys.EVALUATED_MENTEE)
const facility = localStorage.getItem(LocalStorageKeys.SELECTED_FACILITY);
const district = localStorage.getItem(LocalStorageKeys.DISTRICT);
const mentees = await useMentees.fetchAllMentees(facility)

const selectedTool: Ref<any> = ref()
const selectedDistrict: Ref<any> = ref()


selectedTool.value = useProcessLocalStorage().retrieve(LocalStorageKeys.TOOL)
selectedDistrict.value = useProcessLocalStorage().retrieve(LocalStorageKeys.DISTRICT)

watch(menteeData, (newValue, Oldvalue) => {
    if (newValue.show === true) {
        showUserUpdateForm.value = newValue.show
    }
})



const nextStep = async () => {
    //step 1 check to see if there is an entry in selected CoMentors

    if (selectedMentee) {
        //if there is an entry in selected CoMentors do not change the entry go to next step

        await navigateTo(Routes.PREVIEW)
    } else {
        //if there is no entry in selected CoMentors insert an empty entry and proceed

        showAlert.value = true

    }
}

const router = useRouter();

const goBack = () => {
  router.back();
};


onMounted(async () => {
    await useMentees.fetchAllMentees(facility)
})

onUpdated(async () => {
    await useMentees.fetchAllMentees(facility)
})

</script>
<template>
    <div>
        <SharedBorderedNavBar>
            <template #lead>
                <div v-show="!showMenteeForm">
                    <div id="mentees-list" v-if="showUserUpdateForm === false">
                        <!-- <NuxtLink :to="Routes.FACILITIES"> -->
                            <div class="pr-5 text-blue-500 cursor-pointer" @click="goBack">
                                <UIcon name="i-heroicons-arrow-small-left" />
                            </div>
                        <!-- </NuxtLink> -->
                    </div>
                    <div id="mentee-update-form" v-else>

                        <div class="pr-5 text-blue-500 cursor-pointer">
                            <UIcon name="i-heroicons-arrow-small-left" @click="showUserUpdateForm = false" />
                        </div>

                    </div>

                </div>
                <div v-show="showMenteeForm">
                    <div class="pr-5 text-blue-500 cursor-pointer" @click="showMenteeForm = false">
                        <UIcon name="i-heroicons-arrow-small-left" />
                    </div>
                </div>

                <div>
                    <span class=" text-gray-400"><strong>Planning</strong></span> | <span class=" text-sky-700"> {{
                        selectedTool.label }}</span>
                </div>
            </template>
        </SharedBorderedNavBar>

        <UContainer>
            <!-- {{ Mentees }} -->
            <div class=" pt-5 pb-10">
                <div class="pb-5" v-if="showAlert">
                    <UAlert icon="i-heroicons-command-line" color="rose" variant="outline" title="Heads up!"
                        description="You have'nt selected a mentee to evaluate"
                        :close-button="{ icon: 'i-heroicons-x-mark-20-solid', color: 'gray', variant: 'link', padded: false }" />
                </div>
                <div v-show="!showMenteeForm">
                    <div id="mentees-list" v-if="showUserUpdateForm === false">
                        <div class="flex justify-between pb-5">
                            <div class="flex">
                                <div class="text-gray-600 pr-1"> Step 4: </div>
                                <div class="text-orange-500"><strong>Select the mentee to be evaluated</strong></div>
                            </div>
                            <div>
                                <!-- <nuxt-link :to="{ name: 'planning-districts' }"> -->
                                <span v-if="selectedMentee">
                                    <UButton variant="outline" @click="nextStep()">Skip | Next Step</UButton>
                                </span>

                                <!-- </nuxt-link> -->
                            </div>

                        </div>
                        <div class=" flex gap-1">
                            <div>
                                <UButton variant="soft" color="green">
                                    {{ district }}
                                </UButton>
                            </div>
                            <div class=" py-1">
                                <UIcon name="i-heroicons-chevron-double-right" />
                            </div>
                            <div>
                                <UButton variant="soft" color="orange">
                                    {{ facility }}
                                </UButton> 
                            </div>
                        </div>
                        <!-- {{ facility  }}
                        {{ selectedMentee }} -->
                        <TablesMentees :mentees="mentees" @show-create-user-form="showMenteeForm = $event"
                            @mentee-data="menteeData = $event" />
                    </div>
                    <div id="mentee-update-form" v-else>
                        <div class="flex justify-between pb-5">
                            <div class="flex">
                                <div class="text-gray-600 pr-1"> Step 4: </div>
                                <div class="text-orange-500"><strong>Update Mentees</strong></div>
                            </div>
                        </div>

                        <FormsUpdateMentee :mentee-data="menteeData"
                            @show-update-user-form="showUserUpdateForm = $event" />
                    </div>

                </div>
            </div>

        </UContainer>
    </div>
</template>