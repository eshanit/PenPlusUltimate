<script setup lang="ts">
import DatabaseNames from "@/constants/DatabaseNames";
import SelectedMentees from "~/components/tables/selectedMentees.vue";


const router = useRouter();

const goBack = () => {
    router.back();
};
//
//mentees
const useMentees = useMenteeStore();

const mentees: any = await useMentees.fetchMentees();

//evaluations
const useEvaluations = useEvalDataStore();

const completedEvals = await useEvaluations.fetchEvaluationScores(DatabaseNames.COMPLETED_EVALUTATIONS);

const evaluationStats = useEvaluationStats(completedEvals)

const genderCounts = computed(() => {
    const males = mentees.filter((m: any) => m.gender == 'Male')
    const females = mentees.filter((m: any) => m.gender == 'Female')
    const Other = mentees.filter((m: any) => m.gender == 'Other')

    return {
        Males: males.length,
        Females: females.length,
        Other: Other.length
    }
})

const chartOptions = {
    series: Object.values(genderCounts.value),
    options: {
        chart: {
            width: 380,
            type: 'pie',
        },
        labels: Object.keys(genderCounts.value),
        responsive: [{
            breakpoint: 480,
            options: {
                chart: {
                    width: 200
                },
                legend: {
                    position: 'bottom'
                }
            }
        }]
    }
}

</script>
<template>
    <SharedBorderedNavBar>
        <template #lead>
            <!-- <NuxtLink :to="Routes.COMPLETED_EVALUATIONS.path"> -->
            <div class="pr-5 text-blue-500 cursor-pointer" @click="goBack">
                <UIcon name="i-heroicons-arrow-small-left" />
            </div>
            <!-- </NuxtLink> -->
            <div>
                <span class=" text-gray-400"><strong>Mentees</strong></span> | <span class=" text-orange-500">
                    Reporting and Analysis</span>
            </div>
        </template>
    </SharedBorderedNavBar>

    <UContainer>
       <UDivider label="List of Mentees" class="py-5"/>

        <SelectedMentees :mentees="mentees" :evaluations="completedEvals" />

        <UDivider label="Break Down by Gender" class="py-5"/>
        <div class="mt-12 grid grid-cols-2 gap-5">
            <div>
                <apexchart type="pie" width="380" :options="chartOptions.options" :series="chartOptions.series"></apexchart>
            </div>
            <div>
                <div class="grid grid-cols-2 font-bold">
                    <div>
                        Gender
                    </div>
                    <div>
                        Count
                    </div>
                </div>
                <div class="grid grid-cols-2 border-t py-2.5">
                    <div>
                        Male
                    </div>
                    <div>
                        {{ genderCounts?.Males }}
                    </div>
                </div>
                <div class="grid grid-cols-2 border-t py-2.5">
                    <div>
                        Female
                    </div>
                    <div>
                        {{ genderCounts?.Females }}
                    </div>
                </div>
                <div class="grid grid-cols-2 border-t py-2.5">
                    <div>
                        Other/Not Given
                    </div>
                    <div>
                        {{ genderCounts?.Other }}
                    </div>
                </div>
            </div>
        </div>
        
    </UContainer>

</template>