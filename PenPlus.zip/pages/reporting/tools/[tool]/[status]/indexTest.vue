<script setup lang="ts">
import { ref, watch, onMounted } from 'vue';
import { useRoute, useRouter, onBeforeRouteUpdate } from 'vue-router';
import DatabaseNames from "@/constants/DatabaseNames";
import capitalizeFirstLetter from "@/utilities/capitalizeFirstLetter";

const route = useRoute();
const router = useRouter();
const tool = route.params.tool;
const status = route.params.status;

const showTool = ref(false);
const completedEvals: any = ref([]);

const useEvaluations = useEvalDataStore();

// Fetch data on component mount
onMounted(async () => {
    console.log('Component mounted, fetching data...');
    completedEvals.value = await useEvaluations.fetchEvaluationScores(DatabaseNames.COMPLETED_EVALUTATIONS);
    console.log('Data fetched:', completedEvals.value);
});

// Watch for route changes
watch(
    () => route.params,
    async (newParams) => {
        console.log('Route params changed:', newParams);
        completedEvals.value = await useEvaluations.fetchEvaluationScores(DatabaseNames.COMPLETED_EVALUTATIONS);
        console.log('Data fetched:', completedEvals.value);
    },
    { immediate: true }
);

// Handle route updates
onBeforeRouteUpdate(async (to, from, next) => {
    console.log('Route updated, fetching data...');
    completedEvals.value = await useEvaluations.fetchEvaluationScores(DatabaseNames.COMPLETED_EVALUTATIONS);
    next();
});

const goBack = () => {
    router.back();
};

const tools = useTools;
const toolObj = tools.find((el) => el.name == tool);

const toolsEvals = computed(() => {
    const evaluationStats = useEvaluationStats(completedEvals.value);

    let evals;

    if (status == 'completed') {
        evals = evaluationStats.completedEvaluations.filter((el) => el.tool == tool);
    } else if (status == 'twocompleted') {
        evals = evaluationStats.completed2Evals.filter((el) => el.tool == tool);
    } else if (status == 'onecompleted') {
        evals = evaluationStats.completed1Evals.filter((el) => el.tool == tool);
    } else {
        evals = completedEvals.value.filter((el: any) => el.tool == tool);
    }

    return evals;
});
</script>

<template>
    <!-- <pre>
        {{ toolsEvals   }}
    </pre> -->
    <div :key="route.fullPath">
        <div v-if="completedEvals && completedEvals.length > 0">
            <SharedBorderedNavBar>
                <template #lead>
                    <div v-show="!showTool">
                        <div class="pr-5 text-blue-500 cursor-pointer" @click="goBack">
                            <UIcon name="i-heroicons-arrow-small-left" />
                            Back
                        </div>
                    </div>
                    <div v-show="showTool">
                        <div class="pr-5 text-blue-500 cursor-pointer" @click="showTool = false">
                            <UIcon name="i-heroicons-arrow-small-left" />
                        </div>
                    </div>
                </template>
            </SharedBorderedNavBar>
            <UContainer>
                <div class="flex justify-between">
                    <div class="flex gap-1 py-5">
                        <div class="text-red-700 text-3xl">{{ toolObj?.label }}</div>
                        <div class="mt-2.5">
                            <div v-if="status == 'completed'">
                                <UBadge color="sky">
                                    {{ capitalizeFirstLetter(status) }}
                                </UBadge>
                            </div>
                            <div v-else-if="status == 'twocompleted'">
                                <UBadge color="orange">
                                    Two sessions completed
                                </UBadge>
                            </div>
                            <div v-else-if="status == 'onecompleted'">
                                <UBadge color="red">
                                    One session completed
                                </UBadge>
                            </div>
                            <div v-else>
                                <UBadge color="green">
                                    All scenarios
                                </UBadge>
                            </div>
                        </div>
                    </div>

                    <div class="flex gap-5 py-5">
                        <div class="mt-2">
                            Mean Score:
                        </div>
                        <div class=" font-bold text-3xl text-sky-500">
                            {{ useEvaluationStats(toolsEvals).overallMeanScore }}
                        </div>
                    </div>
                </div>

                <UDivider class="py-5" label="Evaluation Dates" />
                <TablesSelectedEvaluations :evaluations="toolsEvals" />

                <UDivider class="py-5" label="Evaluation Means" />
                <div v-if="tool == 'echo'">
                    No Data for this tool
                </div>
                <div v-else>
                    <TablesSelectedEvaluationMeans :evaluations="toolsEvals" />
                </div>
            </UContainer>
        </div>
        <div v-else>
            Loading...
        </div>
    </div>
</template>