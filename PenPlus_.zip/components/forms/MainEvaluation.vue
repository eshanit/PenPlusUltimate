<script setup lang="ts">
import * as yup from "yup";
import Routes from "@/constants/Routes";
import generateID from "@/utilities/generateID";
import LocalStorageKeys from "@/constants/LocalStorageKeys";
import { useStorage } from '@vueuse/core'
import type ITools from "@/interfaces/ITools";


const props = defineProps<{
    menteeData: any,
    selectedTool: string|string[],
    evaluationItems: any
}>()

const schema = yup.object({
    // _id: yup.string().label("id"),
    // mentee: yup.object().label("Mentee Information"),
    evalDate: yup.string().label("Date Today"),
    evalItemScores: yup.array().required().min(0).label("Score"),
});

const itemScores: Ref<any[]> = ref([])

props.evaluationItems.forEach((evalItem: any) => {
    itemScores.value.push({
        name: evalItem.number,
        score: undefined,
    })
})


const init = {
    // _id: generateID(),
    // mentee: props.menteeData,
    // tool: props.selectedTool,
    evalDate: Date.now(),
    evalItemScores: itemScores.value
}

const state = reactive(init)
const localStorageState = useStorage(LocalStorageKeys.SCORES, state)

</script>
<template>
    <UForm :state="state" @submit="" class="space-y-4">
        <div v-for="(item, index) in evaluationItems" class=" py-2.5">
            <SharedTwCard>
                <template #body>
                    <div class="flex justify-between">
                        <div class="flex gap-2">
                            <span class="font-bold text-orange-500">{{ item.number }}</span>
                            <span class=""> {{ item.title }}</span>
                        </div>

                        <div>
                            <UFormGroup label="" name="Score">
                                <USelect v-model="localStorageState.evalItemScores[index].score" :options="item.scoring"
                                    option-attribute="score" value-attribute="score" />
                            </UFormGroup>
                        </div>
                    </div>

                </template>
            </SharedTwCard>
        </div>
        <div>
            <div class=" flex justify-end py-5" >
                <NuxtLink :to="{
                    name: Routes.EVALUATION_SUMMARY.name,
                    params: {
                        tool: selectedTool,
                    }
                }">
                    <UButton variant="outline" icon="i-heroicons-chevron-double-right" :trailing="true" color="orange"
                        size="xl">
                        Next
                    </UButton>
                </NuxtLink>
                <!-- <UButton class="ml-4" color="white" variant="outline" type="button" @click="resetForm()">
                    Reset
                </UButton> -->
            </div>
        </div>


    </UForm>
</template>