<script setup lang="ts">
import type IDistrict from "@/interfaces/IDistrict";
import processScores from "~/utilities/processScores";
import evaluationItemData from "@/data/evaluationItemData";

const router = useRouter()
const goBack = () => {
    router.back();
};

const route = useRoute()
const district: any = route.params.district

const useEvaluations = useEvalDataStore();

const districtEvals: any = await useEvaluations.fetchDistrictEvaluations(district)

//
const evaluationStats = useEvaluationStats(districtEvals)

const evalCounts = useCountDistrictSessionsCompleted(district, evaluationStats);

const totalSessions = computed(() => {
    return (evalCounts.oneCompletedCount + 2 * (evalCounts.twoCompletedCount) + 3 * (evalCounts.allCompletedCount))
})

///
const tools = useTools;

const selectedTool = ref('diabetes')

const toolEvaluationCounts = computed(() => {
    let counts: any[] = []
    tools.forEach((tool) => {
        counts.push({
            tool: tool.label,
            total: useCountToolSessionsCompleted(tool.name, evaluationStats).totalCompletedCount,
            totalSessions: useCountToolSessionsCompleted(tool.name, evaluationStats).totalCompletedSessions
        })
    });

    return counts;
})

//
// Finding highest totals
const maxToolTotal = Math.max(...toolEvaluationCounts.value.map(tool => tool.total));
const highestToolTotals = toolEvaluationCounts.value.filter(tool => tool.total === maxToolTotal);

// Finding lowest totals
const minToolTotal = Math.min(...toolEvaluationCounts.value.map(tool => tool.total));
const lowestToolTotals = toolEvaluationCounts.value.filter(tool => tool.total === minToolTotal);

//
const isToolHighestOpen = ref(false)
const isToolLowestOpen = ref(false)


///Facility
const useDistricts = useDistrictsStore();

const districts: Array<IDistrict> = await useDistricts.fetchDistricts();

const districtData = districts.find((el: IDistrict) => el.district == district)

const facilities = districtData?.facilities

const facilityEvaluationCounts = computed(() => {
    let counts: any[] = []
    facilities?.forEach((facility) => {
        counts.push({
            facility: facility,
            total: useCountFacilitySessionsCompleted(facility, evaluationStats).totalCompletedCount,
            totalSessions: useCountFacilitySessionsCompleted(facility, evaluationStats).totalCompletedSessions,
        })
    })

    return counts
})

// Finding highest totals
const maxFacilityTotal = Math.max(...facilityEvaluationCounts.value.map((facility: { total: any; }) => facility.total));
const highestFacilityTotals = facilityEvaluationCounts.value.filter((facility: { total: number; }) => facility.total === maxFacilityTotal);

// Finding lowest totals
const minFacilityTotal = Math.min(...facilityEvaluationCounts.value.map(facility => facility.total));
const lowestFacilityTotals = facilityEvaluationCounts.value.filter(facility => facility.total === minFacilityTotal);

//
const isFacilityHighestOpen = ref(false)
const isFacilityLowestOpen = ref(false)


//mixed chart

const sessionFacilityCounts = facilityEvaluationCounts.value.map((counts) => counts.totalSessions)
const evalFacilityCounts = facilityEvaluationCounts.value.map((counts) => counts.total)

//showTable
const showFacilitySessionEvalsTable = ref(false)

const latestEvalScores = useLatestSessionEvals(districtEvals)

const latestEvalScoresCountsPerTool = (tool: string) => {

    const results = latestEvalScores.filter((el: any) => el.tool == tool)

    const scores = results.map(el => el.scores).flat()

    const result: any = {};

    scores.forEach((item) => {
        
        const name = item.name;
        const score = Number(item.score);
        const scoreKey = `score${score}`;

        // Initialize the name entry if it doesn't exist
        if (!result[name]) {
            result[name] = { score1: 0, score2: 0, score3: 0 };
        }

        // Increment the appropriate score count if valid (1-3)
        if (result[name][scoreKey] !== undefined) {
            result[name][scoreKey]++;
        }
    });

    return result

}

//
const toolData = computed(() => {
    const result = evaluationItemData.filter((t: { tool: string; }) =>t.tool == selectedTool.value);

    const newResult: any[] = [];

    const items: any[] = [];

    result.forEach((r: { evaluationItems: any[]; }) => {


        r.evaluationItems.forEach((e) =>{

            const counts = latestEvalScoresCountsPerTool(selectedTool.value)

            items.push({
                item: e.number,
                title: e.title,
                numberof3: counts[e.number]?.score3 ?? null,
                numberof2: counts[e.number]?.score2 ?? null,
                numberof1: counts[e.number]?.score1 ?? null,
            })
        })

    })

    return items

})

</script>
<template>
    <SharedBorderedNavBar>
        <template #lead>
            <!-- <NuxtLink :to="Routes.COMPLETED_EVALUATIONS.path"> -->
            <div class="pr-5 text-blue-500 cursor-pointer" @click="goBack">
                <UIcon name="i-heroicons-arrow-small-left" />
            </div>
            <!-- </NuxtLink> -->
            <div>
                <span class=" text-gray-400"><strong>Districts</strong></span> | <span
                    class=" text-green-500 font-bold">{{ district }}</span> |<span class=" text-orange-500">
                    Analysis</span>
            </div>
        </template>
    </SharedBorderedNavBar>
    <!-- <pre>
    {{ toolData }}
</pre> -->

    <UContainer>
        <div class="grid grid-cols-12 gap-5 pt-10">
            <div class="grid col-span-4">
                <div>
                    <div class="">
                        <div class="">
                            Evaluations done in the whole district:
                        </div>
                        <UDivider class="py-1.5" />
                        <div class="text-5xl text-sky-500 font-semibold">
                            {{ evalCounts.totalCompletedCount }}
                        </div>
                    </div>
                    <div class="py-5" />
                    <div class="">
                        <div class="">
                            Sessions done in the whole district:
                        </div>
                        <UDivider class="py-1.5" />
                        <div class="text-5xl text-rose-500 font-semibold">
                            {{ totalSessions }}
                        </div>
                    </div>
                </div>
            </div>
            <div class="grid col-span-4">
                <div>
                    <div class="">
                        <div class="">
                            Most evaluated Tool(s):
                            <span class="italic font-bold" v-if="highestToolTotals.length == 1">
                                ({{ maxToolTotal }} Evaluations)
                            </span>
                            <span v-else-if="highestToolTotals.length > 0">
                                ({{ maxToolTotal }} Evaluations each)
                            </span>

                        </div>
                        <UDivider class="py-1.5" />
                        <div class="text-5xl text-lime-500 font-semibold">
                            <span v-if="highestToolTotals.length == 1">
                                {{ highestToolTotals[0].tool }}
                            </span>
                            <span v-else-if="highestToolTotals.length > 0">
                                <UButton variant="soft" color="lime" @click="isToolHighestOpen = true">
                                    {{ highestToolTotals.length }} Tools
                                </UButton>
                            </span>
                            <span v-else>
                                -
                            </span>
                        </div>
                    </div>
                    <div class="py-5" />
                    <div class="">
                        <div class="">
                            Least Evaluated Tool(s):
                            <span class="italic font-bold" v-if="lowestToolTotals.length == 1">
                                ({{ minToolTotal }} Evaluations)
                            </span>
                            <span class="italic font-bold" v-else-if="lowestToolTotals.length > 0">
                                ({{ minToolTotal }} Evaluations each)
                            </span>
                        </div>
                        <UDivider class="py-1.5" />
                        <div class="text-5xl text-orange-500 font-semibold">
                            <span v-if="lowestToolTotals.length == 1">
                                {{ lowestToolTotals[0].tool }}
                            </span>
                            <span v-else-if="highestToolTotals.length > 0">
                                <UButton variant="soft" color="orange" size="lg" @click="isToolLowestOpen = true">
                                    {{ lowestToolTotals.length }} Tools
                                </UButton>
                            </span>
                            <span v-else>
                                -
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="grid col-span-4">
                <div>
                    <div class="">
                        <div class="">
                            Facility(s) with most evaluations:
                            <span class="italic font-bold" v-if="highestFacilityTotals.length == 1">
                                ({{ maxFacilityTotal }} Evaluations)
                            </span>
                            <span v-else-if="highestFacilityTotals.length > 0">
                                ({{ maxFacilityTotal }} Evaluations each)
                            </span>

                        </div>
                        <UDivider class="py-1.5" />
                        <div class="text-5xl text-purple-500 font-semibold">
                            <span v-if="highestFacilityTotals.length == 1">
                                {{ highestFacilityTotals[0].facility }}
                            </span>
                            <span v-else-if="highestFacilityTotals.length > 0">
                                <UButton variant="soft" color="purple" @click="isFacilityHighestOpen = true">
                                    {{ highestFacilityTotals.length }} Facilities
                                </UButton>
                            </span>
                            <span v-else>
                                -
                            </span>
                        </div>
                    </div>
                    <div class="py-5" />
                    <div class="">
                        <div class="">
                            Facility(s) with least evaluations:
                            <span class="italic font-bold" v-if="lowestFacilityTotals.length == 1">
                                ({{ minFacilityTotal }} Evaluations)
                            </span>
                            <span class="italic font-bold" v-else-if="lowestFacilityTotals.length > 0">
                                ({{ minFacilityTotal }} Evaluations each)
                            </span>
                        </div>
                        <UDivider class="py-1.5" />
                        <div class="text-5xl text-teal-500 font-semibold">
                            <span v-if="lowestFacilityTotals.length == 1">
                                {{ lowestFacilityTotals[0].facility }}
                            </span>
                            <span v-else-if="highestFacilityTotals.length > 0">
                                <UButton variant="soft" color="teal" size="lg" @click="isFacilityLowestOpen = true">
                                    {{ lowestFacilityTotals.length }} Facilities
                                </UButton>
                            </span>
                            <span v-else>
                                -
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <UDivider label="Evaluations breakdown" :ui="{ label: 'text-primary-500 dark:text-primary-400' }"
            class="py-5" />
        <div class=" grid grid-cols-2 gap-5">
            <div>
                <ChartsDistrictsEvaluationsBar :eval-counts="evalCounts" />
            </div>
            <div>
                <ChartsDistrictsEvaluationsPie :eval-counts="evalCounts" />
            </div>
        </div>
        <UDivider label="Facility Sessions And Evaluations" :ui="{ label: 'text-primary-500 dark:text-primary-400' }"
            class="py-5" />

        <div class="py-5" v-if="!showFacilitySessionEvalsTable">
            <div>
                <UButton color="orange" variant="outline" label="View As Table"
                    @click="showFacilitySessionEvalsTable = true" />
            </div>
            <div class="py-5" />
            <ChartsDistrictsEvaluationsSessionMixed :facilities="facilities" :eval-counts="evalFacilityCounts"
                :session-counts="sessionFacilityCounts" />
        </div>
        <div class="py-5" v-else>
            <div>
                <UButton color="orange" variant="outline" label="View As Chart"
                    @click="showFacilitySessionEvalsTable = false" />
            </div>
            <div class="py-5" />
            <TablesAGtablesDistrictsFSessionEvals :facility-data="facilityEvaluationCounts" />
        </div>
        <UDivider label="Tool Analysis" :ui="{ label: 'text-primary-500 dark:text-primary-400' }"
        class="py-5" />

        <div>
            Select tool to view score counts
        </div>
        <div class="py-5 w-1/3">
            <!-- {{ selectedTool }} -->
            <USelect v-model="selectedTool" :options="tools" option-attribute="label"  value-attribute="name" />
        </div>

        <div class=" pb-10">
            <div v-if="Object.values(latestEvalScoresCountsPerTool(selectedTool)).length != 0">
                <TablesAGtablesDistrictsToolScores :tool-data="toolData" />
            </div>
            <div v-else>
                No evaluations recorded for <span class="font-bold"> {{  selectedTool }}</span> in {{  district }} district.
            </div>
          
        </div>

    </UContainer>
    <USlideover v-model="isToolLowestOpen">
        <div class="p-4 flex-1">
            <UButton color="gray" variant="ghost" size="sm" icon="i-heroicons-x-mark-20-solid"
                class="flex sm:hidden absolute end-5 top-5 z-10" square padded @click="isToolLowestOpen = false" />

            <div class=" pt-10 pb-5">
                Least evaluated tools in <span class="font-bold text-orange-500">{{ district }}</span> district
            </div>
            <div class="p-5 border rounded-lg">
                <div class="grid grid-cols-2 gap-5 font-bold bg-orange-400 px-2">
                    <div>
                        Tool
                    </div>
                    <div>
                        Number of Evaluations
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-5 py-2.5 border-t cursor-pointer px-2 hover:bg-gray-100"
                    v-for="tool in lowestToolTotals">
                    <div>
                        {{ tool.tool }}
                    </div>
                    <div class="text-center">
                        {{ tool.total }}
                    </div>
                </div>
            </div>
        </div>
    </USlideover>

    <USlideover v-model="isToolHighestOpen">
        <div class="p-4 flex-1">
            <UButton color="gray" variant="ghost" size="sm" icon="i-heroicons-x-mark-20-solid"
                class="flex sm:hidden absolute end-5 top-5 z-10" square padded @click="isToolHighestOpen = false" />

            <div class=" pt-10 pb-5">
                Most evaluated tools in <span class="font-bold text-lime-500">{{ district }}</span> district
            </div>
            <div class="p-5 border rounded-lg">
                <div class="grid grid-cols-2 gap-5 font-bold bg-lime-400 px-2">
                    <div>
                        Tool
                    </div>
                    <div>
                        Number of Evaluations
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-5 py-2.5 border-t cursor-pointer px-2 hover:bg-gray-100"
                    v-for="tool in highestToolTotals">
                    <div>
                        {{ tool.tool }}
                    </div>
                    <div class="text-center">
                        {{ tool.total }}
                    </div>
                </div>
            </div>
        </div>
    </USlideover>

    <USlideover v-model="isFacilityHighestOpen">
        <div class="p-4 flex-1">
            <UButton color="gray" variant="ghost" size="sm" icon="i-heroicons-x-mark-20-solid"
                class="flex sm:hidden absolute end-5 top-5 z-10" square padded @click="isFacilityHighestOpen = false" />

            <div class=" pt-10 pb-5">
                Facilities with most evaluations in <span class="font-bold text-purple-500">{{ district }}</span>
                district
            </div>
            <div class="p-5 border rounded-lg">
                <div class="grid grid-cols-2 gap-5 font-bold bg-purple-400 px-2">
                    <div>
                        Facility
                    </div>
                    <div>
                        Number of Evaluations
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-5 py-2.5 border-t cursor-pointer px-2 hover:bg-gray-100"
                    v-for="facility in highestFacilityTotals">
                    <div>
                        {{ facility.facility }}
                    </div>
                    <div class="text-center">
                        {{ facility.total }}
                    </div>
                </div>
            </div>
        </div>
    </USlideover>

    <USlideover v-model="isFacilityLowestOpen">
        <div class="p-4 flex-1">
            <UButton color="gray" variant="ghost" size="sm" icon="i-heroicons-x-mark-20-solid"
                class="flex sm:hidden absolute end-5 top-5 z-10" square padded @click="isFacilityLowestOpen = false" />

            <div class=" pt-10 pb-5">
                Facilities with the least evaluations in <span class="font-bold text-teal-500">{{ district }}</span>
                district
            </div>
            <div class="p-5 border rounded-lg">
                <div class="grid grid-cols-2 gap-5 font-bold bg-teal-400 px-2">
                    <div>
                        Facility
                    </div>
                    <div>
                        Number of Evaluations
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-5 py-2.5 border-t cursor-pointer px-2 hover:bg-gray-100"
                    v-for="facility in lowestFacilityTotals">
                    <div>
                        {{ facility.facility }}
                    </div>
                    <div class="text-center">
                        {{ facility.total }}
                    </div>
                </div>
            </div>
        </div>
    </USlideover>
</template>