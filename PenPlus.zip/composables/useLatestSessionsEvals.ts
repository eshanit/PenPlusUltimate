import type IScore from "@/interfaces/IScore";
import type IFinalEvaluation from "@/interfaces/IFinalEvaluation";


export function useLatestSessionEvals(evaluations :IFinalEvaluation[]) {
   

    const completedEvaluations = evaluations.filter((evaluation) => {
        const sessions = evaluation.sessions;
        return sessions.session_1 && sessions.session_2 && sessions.session_3 && sessions.session_4 && sessions.session_5;
      });
    
      const completed4Evals = evaluations.filter((evaluation) => {

        const sessions = evaluation.sessions;
        return sessions.session_1 && sessions.session_2 && sessions.session_3  && sessions.session_4  && sessions.session_5 == null;
       
      });
    
    
      const completed3Evals = evaluations.filter((evaluation) => {
    
        const sessions = evaluation.sessions;
        return sessions.session_1 && sessions.session_2 && sessions.session_3 && sessions.session_4 == null && sessions.session_5 == null;
       
      });
    
    
      const completed2Evals = evaluations.filter((evaluation) => {
    
        const sessions = evaluation.sessions;
        return sessions.session_1 && sessions.session_2 && sessions.session_3 == null && sessions.session_4 == null && sessions.session_5 == null;
       
      });
    
      const completed1Evals = evaluations.filter((evaluation) => {
    
        const sessions = evaluation.sessions;
        return sessions.session_1 && sessions.session_2 == null && sessions.session_3 == null && sessions.session_4 == null && sessions.session_5 == null;
       
      });

         // for those with 5 sessions

         const latestSession5Scores = completedEvaluations.map(evaluation => {
          const sessions: any = evaluation.sessions;
          const latestSessionKey:any = "session_5"; // Get the latest session key
          const latestSession:any = sessions[latestSessionKey];
      
          return {
              _id: evaluation._id,
              evaluator: evaluation.evaluator,
              evaluationID: evaluation.evaluationID,
              mentee: evaluation.mentee,
              tool: evaluation.tool,
              latestSession: latestSessionKey,
              scores: latestSession.evalItemScores || null // Scores might be null
          };
      });

         // for those with 4 sessions

         const latestSession4Scores = completed4Evals.map(evaluation => {
          const sessions: any = evaluation.sessions;
          const latestSessionKey:any = "session_4"; // Get the latest session key
          const latestSession:any = sessions[latestSessionKey];
      
          return {
              _id: evaluation._id,
              evaluator: evaluation.evaluator,
              evaluationID: evaluation.evaluationID,
              mentee: evaluation.mentee,
              tool: evaluation.tool,
              latestSession: latestSessionKey,
              scores: latestSession.evalItemScores || null // Scores might be null
          };
      });

      // for those with 3 sessions

      const latestSession3Scores = completed3Evals.map(evaluation => {
        const sessions: any = evaluation.sessions;
        const latestSessionKey:any = "session_3"; // Get the latest session key
        const latestSession:any = sessions[latestSessionKey];
    
        return {
            _id: evaluation._id,
            evaluator: evaluation.evaluator,
            evaluationID: evaluation.evaluationID,
            mentee: evaluation.mentee,
            tool: evaluation.tool,
            latestSession: latestSessionKey,
            scores: latestSession.evalItemScores || null // Scores might be null
        };
    });

      // for those with 2 sessions

      const latestSession2Scores = completed2Evals.map(evaluation => {
        const sessions: any = evaluation.sessions;
        const latestSessionKey:any = "session_2"; // Get the latest session key
        const latestSession:any = sessions[latestSessionKey];
    
        return {
            _id: evaluation._id,
            evaluator: evaluation.evaluator,
            evaluationID: evaluation.evaluationID,
            mentee: evaluation.mentee,
            tool: evaluation.tool,
            latestSession: latestSessionKey,
            scores: latestSession.evalItemScores || null // Scores might be null
        };
    })
    
      // for those with 1 session

      const latestSession1Scores = completed1Evals.map(evaluation => {
        const sessions: any = evaluation.sessions;
        const latestSessionKey:any = "session_1"; // Get the latest session key
        const latestSession:any = sessions[latestSessionKey];
    
        return {
            _id: evaluation._id,
            evaluator: evaluation.evaluator,
            evaluationID: evaluation.evaluationID,
            mentee: evaluation.mentee,
            tool: evaluation.tool,
            latestSession: latestSessionKey,
            scores: latestSession.evalItemScores || null // Scores might be null
        };
    })
    

    return [latestSession1Scores, latestSession2Scores, latestSession3Scores, latestSession4Scores, latestSession5Scores ].flat()
}