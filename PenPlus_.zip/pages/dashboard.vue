<script setup lang="ts">
import type IDistrict from "@/interfaces/IDistrict";
import Routes from '@/constants/Routes';
import DatabaseNames from "@/constants/DatabaseNames";
import ToolEvaluations from "~/components/tables/AGtables/Dashboard/ToolEvaluations.vue";

const facilities: Ref<Array<string>> = ref([])

const user = useUserDetails;

//districts

const useDistricts = useDistrictsStore();

const districts: Array<IDistrict> = await useDistricts.fetchDistricts();

districts?.forEach((d: any) => {
    facilities.value.push(d.facilities);
})

//mentees
const useMentees = useMenteeStore();

const mentees = await useMentees.fetchMentees();

//evaluations
const useEvaluations = useEvalDataStore();

const completedEvals = await useEvaluations.fetchEvaluationScores(DatabaseNames.COMPLETED_EVALUTATIONS);

const evaluationStats = useEvaluationStats(completedEvals)

//progress tracking
const tools = useTools

const countSessionsCompleted = (tool: string) => {

    const allCompleted = evaluationStats.completedEvaluations.filter((el) => {
        return el.tool == tool
    })

    const twoCompleted = evaluationStats.completed2Evals.filter((el) => {
        return el.tool == tool
    })

    const oneCompleted = evaluationStats.completed1Evals.filter((el) => {
        return el.tool == tool
    })

    return {
        allCompletedCount: allCompleted.length,
        twoCompletedCount: twoCompleted.length,
        oneCompletedCount: oneCompleted.length
    }

}

const countSessionsFacility = (facility: string) => {
    const allCompleted = evaluationStats.completedEvaluations.filter((el) => {
        return el.mentee.facility == facility
    })

    const twoCompleted = evaluationStats.completed2Evals.filter((el) => {
        return el.mentee.facility == facility
    })

    const oneCompleted = evaluationStats.completed1Evals.filter((el) => {
        return el.mentee.facility == facility
    })

    return {
        allCompletedCount: allCompleted.length,
        twoCompletedCount: twoCompleted.length,
        oneCompletedCount: oneCompleted.length
    }
}

</script>

<template>
    <SharedNavBar>
        <template #lead>
            <div class="font-bold text-red-700">
                Dashboard
            </div>
        </template>
    </SharedNavBar>

    <UDivider label="Key Performance Indicators" />

    <UContainer>
        <!-- Your content here -->
        <div class="flex justify-between pt-20 gap-5">

            <div ref="overdue"
                class="flex-grow text-center rounded-lg hover:bg-sky-500 hover:shadow-lg  hover:text-white">
                <NuxtLink :to="Routes.DISTRICTS_REPORTING.path">
                    <div class="border-b">Districts</div>
                    <div class="text-5xl">{{ districts?.length }}</div>
                </NuxtLink>
            </div>

            <div ref="open" class="flex-grow text-center rounded-lg hover:bg-sky-500 hover:shadow-lg  hover:text-white">
                <NuxtLink :to="Routes.FACILITIES_REPORTING.path">
                    <div class="border-b">Facilities</div>
                    <div class="text-5xl">{{ facilities?.flat().length }}</div>
                </NuxtLink>
            </div>
            <div ref="draft"
                class="flex-grow text-center rounded-lg hover:bg-sky-500 hover:shadow-lg  hover:text-white">
                <NuxtLink :to="Routes.MENTEES_REPORTING.path">
                    <div class="border-b">Mentees</div>
                    <div class="text-5xl">{{ mentees?.length }}</div>
                </NuxtLink>
            </div>
            <div ref="draft" class="flex-grow text-center">
                <div class="border-b">Evaluations</div>
                <div class="text-5xl">{{ completedEvals?.length }}</div>
            </div>
        </div>
        <div class="py-10" />
        <div class="grid grid-cols-2 gap-5">
            <SharedTwCard>
                <template #body>
                    <div class="text-center">
                        <div class="font-bold py-5">Overall Mean Score </div>
                        <div class="text-5xl text-green-500 font-bold">{{ evaluationStats.overallMeanScore }}</div>
                    </div>
                </template>
            </SharedTwCard>
            <SharedTwCard>
                <template #body>
                    <div class="text-center">
                        <div class="font-bold py-5">Completed Evaluations </div>
                        <div class="text-5xl text-orange-500 font-bold">{{ evaluationStats.completedEvaluations.length
                        }}</div>
                    </div>
                </template>
            </SharedTwCard>
        </div>

        <UDivider label="Progress Tracking" class="py-10" />
        <div ref="NCD Tool Eval" class="pb-10">
            <div class="font-bold pb-5 text-orange-500">Evaluations by NCD Tool:</div>
            <TablesAGtablesDashboardToolEvaluations :evaluation-stats="evaluationStats" />
        </div>

        <div ref="NCD Tool Eval" class="pb-10">
            <div class="font-bold pb-5 text-orange-500">Evaluations by Facilities:</div>
            <TablesAGtablesDashboardFacilityEvaluations :evaluation-stats="evaluationStats" :facilities="facilities?.flat()" />
        </div>

    </UContainer>
</template>

<style scoped>
/* Additional custom styles */

.text-pretty {
    color: #3B82F6;
    /* Sky color */
}

.icon-size {
    width: 100%;
    /* Fill the container width */
    height: auto;
    /* Maintain aspect ratio */
    max-height: 100px;
    /* Limit height for larger icons */
}

@media (max-width: 768px) {
    .text-lg {
        font-size: 1.5rem;
        /* Larger text on mobile */
    }

    .icon-size {
        max-height: 80px;
        /* Adjust icon size for smaller screens */
    }
}
</style>