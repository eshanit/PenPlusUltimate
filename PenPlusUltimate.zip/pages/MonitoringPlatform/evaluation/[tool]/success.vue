<script setup lang="ts">
import LocalStorageKeys from "@/constants/LocalStorageKeys";
import Routes from "@/constants/Routes";

const route = useRoute()
const tool = route.params.tool

const menteeData: any = useProcessLocalStorage().retrieve(LocalStorageKeys.EVALUATED_MENTEE)

const showBar: Ref<Boolean> = ref(false)

const router = useRouter();

const goBack = () => {
    router.back();
};

</script>
<template>
    <SharedBorderedNavBar>
        <template #lead>
            <div v-show="!showBar">
                <!-- <NuxtLink :to="Routes.PREVIEW.path"> -->
                <div class="pr-5 text-blue-500 cursor-pointer" @click="goBack">
                    <UIcon name="i-heroicons-arrow-small-left" />
                </div>
                <!-- </NuxtLink> -->
            </div>
            <div v-show="showBar">
                <div class="pr-5 text-blue-500 cursor-pointer" @click="showBar = false">
                    <UIcon name="i-heroicons-arrow-small-left" />
                </div>
            </div>

            <div>
                <span class="text-gray-400"><strong>Evaluating</strong></span> | <span class="text-sky-700">{{
                    tool }}</span>
            </div>
        </template>
    </SharedBorderedNavBar>
    <UContainer class="flex justify-center items-center h-screen gap-1">
        <div class="text-center text-purple-500 text-5xl">
            Success!
        </div>
        <div>
            <NuxtLink :to="Routes.DASHBOARD.path">
                <UButton color="pink">
                    Done
                </UButton>
            </NuxtLink>
        </div>
    </UContainer>
</template>