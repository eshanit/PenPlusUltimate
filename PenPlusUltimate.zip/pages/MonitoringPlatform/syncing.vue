<script setup lang="ts">
import DatabaseNames from '@/constants/DatabaseNames';
import Routes from '@/constants/Routes';

const toast = useToast()

const syncTo = async (databaseName: string) => {
    const synced = await useReplicateToCouchDB(databaseName)
}

const syncFrom = async (databaseName: string) => {
    const synced = await useReplicateFromCouchDB(databaseName)
}

</script>
<template>
    <div>
        <UContainer>

            <SharedBorderedNavBar>
                <template #lead>
                    <NuxtLink :to="Routes.DASHBOARD">
                        <div class="pr-5 text-blue-500 cursor-pointer">
                            <UIcon name="i-heroicons-arrow-small-left" />
                        </div>
                    </NuxtLink>
                    <div class=" text-gray-400"><strong> Sync your Data</strong></div>
                </template>
            </SharedBorderedNavBar>

         <div class="pt-5">
            <SharedTwCardWithHeader class="bg-gray-300">
                <template #header>
                   <div class="flex gap-5">
                        <div class=" text-red-500 text-3xl animate-pulse"><UIcon name="i-heroicons-exclamation-triangle" /></div>
                        <div>When you update the app, please make sure to sync both <span class="font-bold text-sky-500">districts</span> and <span class="font-bold text-rose-500">mentees</span></div>
                   </div>
                </template>
                <template #body>
                    <div class=" pt-5">
                        <div class="w-1/2 text-center" @click="syncFrom(DatabaseNames.DISTRICTS)">
                            <SharedTwCard>
                                <template #body>
                                    Sync <span class=" text-pretty text-sky-500 font-bold italic">Districts</span>
                                </template>
                            </SharedTwCard>
                        </div>
                    </div>
                    <div class=" pt-5">
                        <div class="w-1/2 text-center" @click="syncFrom(DatabaseNames.MENTEES)">
                            <SharedTwCard>
                                <template #body>
                                    Sync <span class=" text-pretty text-rose-500 font-bold italic">Mentees</span>
                                </template>
                            </SharedTwCard>
                        </div>
                    </div>
                </template>
            </SharedTwCardWithHeader>
         </div>

            <div class=" pt-5">
                <div class="w-1/2 text-center" @click="syncFrom(DatabaseNames.COMPLETED_EVALUTATIONS)">
                    <SharedTwCard>
                        <template #body>
                            Sync <span class=" text-pretty text-fuchsia-500 font-bold italic">Completed
                                Evaluations</span>
                        </template>
                    </SharedTwCard>
                </div>
            </div>
            <div class=" pt-5">
                <div class="w-1/2 text-center" @click="syncTo(DatabaseNames.INCOMPLETE_EVALUATIONS)">
                    <SharedTwCard>
                        <template #body>
                            Sync <span class=" text-pretty text-teal-500 font-bold italic">Incomplete Evaluations</span>
                        </template>
                    </SharedTwCard>
                </div>
            </div>
            <div class=" pt-5">
                <div class="w-1/2 text-center" @click="syncTo(DatabaseNames.COMENTORS)">
                    <SharedTwCard>
                        <template #body>
                            Sync <span class=" text-pretty text-rose-500 font-bold italic">Co-Mentors</span>
                        </template>
                    </SharedTwCard>
                </div>
            </div>

        </UContainer>
    </div>
</template>