export default {
    DISTRICTS: 'districts',
    COMENTORS: 'comentors',
    EVALUATIONS: 'evaluations',
    INCOMPLETE_EVALUATIONS: 'incomplete_evals',
    COMPLETED_EVALUTATIONS: 'pp_scores',
    MENTEES: 'mentees',
    USERS: 'users',
    
}