<script setup lang="ts">
import * as yup from "yup";
import { format } from 'date-fns';
import Routes from "@/constants/Routes";
import generateID from "@/utilities/generateID";
import LocalStorageKeys from "@/constants/LocalStorageKeys";
import { useStorage } from '@vueuse/core';
import { useMaxToolItemData } from '@/composables/useMaxToolItemData'
import type ITools from "@/interfaces/ITools";


const props = defineProps<{
    menteeData: any,
    selectedTool: string | string[],
    evaluationItems: any,
    cutOff?: number
}>();

const schema = yup.object({
    evalDate: yup.string().label("Date Today"),
    evalItemScores: yup.array().required().min(0).label("Score"),
});

const itemScores: Ref<any[]> = ref([]);

props.evaluationItems.forEach((evalItem: any) => {
    itemScores.value.push({
        name: evalItem.number,
        score: undefined,
    });
});

const init = {
    evalDate: Date.now(),
    evalItemScores: itemScores.value
};

const state = reactive(init);
const localStorageState = useStorage(LocalStorageKeys.SCORES, state);
const useEvaluations = useEvalDataStore();
const menteeEvals = await useEvaluations.fetchMenteeEvals(props.menteeData._id);
const toolEvals = menteeEvals.filter((t: { tool: string | string[]; }) => t.tool == props.selectedTool);
const result = useMaxToolItemData(toolEvals);

const maxToolItemData = (itemNum: string): any => {
    return result?.find((r: any) => r.name == itemNum);
};
</script>
<template>
    <UForm :state="state" @submit="" class="space-y-4 px-4 py-6 bg-white text-gray-800">
        <SharedTwCard class="bg-gray-50">
            <template #body>
                <div class="text-xl font-bold text-gray-800 mb-4">
                    Competencies
                </div>
                <div v-for="(item, index) in evaluationItems" :key="item.number" class="py-2.5">
                    <div v-if="props?.cutOff && index < props?.cutOff" class="px-1.5">
                        <div class="flex flex-row gap-5 tablet:flex-row justify-between border-t border-gray-300 pt-4">
                            <div class=" w-3/4 tablet:w-3/4">
                                <div class="flex gap-2">
                                    <span class="font-bold text-orange-500">{{ item.number }}</span>
                                    <span>{{ item.title }}</span>
                                </div>
                                <div class="flex flex-row gap-5 bg-orange-50 rounded-lg p-5 mt-2" v-if="result">
                                    <div class="w-3/4 grid grid-cols-2 gap-5">
                                        <div class="font-bold">Max Score:</div>
                                        <div>
                                            {{ maxToolItemData(item.number).score }}
                                        </div>
                                        <div class="font-bold">Session:</div>
                                        <div>{{ maxToolItemData(item.number).session }}</div>
                                        <div class="font-bold">Date:</div>
                                        <div>{{ format(maxToolItemData(item.number).date, 'yyyy-MM-dd') }}</div>
                                    </div>
                                    <div class="w-1/3" v-if="maxToolItemData(item.number).score == 3">
                                        <div class="text-8xl text-green-400">
                                            <UIcon name="i-heroicons-check-circle" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="flex justify-center w-1/4 tablet:w-1/4 mt-4 tablet:mt-0">
                                <div class="w-1/3">
                                    <UFormGroup label="" name="Score">
                                        <USelect v-model="localStorageState.evalItemScores[index].score"
                                            :options="item.scoring" option-attribute="score" value-attribute="score" />
                                    </UFormGroup>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div v-if="props?.cutOff && index >= props?.cutOff" class="bg-sky-50 px-1.5 rounded-lg">
                        <div class="flex flex-row gap-5 tablet:flex-row justify-between py-5">
                            <div class="w-3/4 tablet:w-3/4">
                                <div class="flex gap-2">
                                    <span class="font-bold text-pink-700">{{ item.number }}</span>
                                    <span>{{ item.title }}</span>
                                </div>

                                <div class="flex flex-row gap-5 bg-orange-50 rounded-lg p-5 mt-2" v-if="result">
                                    <div class="w-3/4 grid grid-cols-2 gap-5">
                                        <div class="font-bold">Max Score:</div>
                                        <div>{{ maxToolItemData(item.number).score }}</div>
                                        <div class="font-bold">Session:</div>
                                        <div>{{ maxToolItemData(item.number).session }}</div>
                                        <div class="font-bold">Date:</div>
                                        <div>{{ format(maxToolItemData(item.number).date, 'yyyy-MM-dd') }}</div>
                                    </div>
                                    <div class="w-1/3" v-if="maxToolItemData(item.number).score == 3">
                                        <div class="text-8xl text-green-400">
                                            <UIcon name="i-heroicons-check-circle" />
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="flex justify-center w-1/4 tablet:w-1/4 mt-4 tablet:mt-0">
                                <div class="w-1/3">
                                    <UFormGroup label="" name="Score">
                                        <USelect v-model="localStorageState.evalItemScores[index].score"
                                            :options="item.scoring" option-attribute="score" value-attribute="score" />
                                    </UFormGroup>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </template>
        </SharedTwCard>

        <div class="flex justify-end py-5">
            <NuxtLink :to="{
                name: Routes?.EVALUATION_SUMMARY.name,
                params: {
                    tool: selectedTool,
                }
            }">
                <UButton 
                    variant="outline" 
                    icon="i-heroicons-chevron-double-right" 
                    :trailing="true" color="orange"
                    size="xl">
                    Next
                </UButton>
            </NuxtLink>
        </div>
    </UForm>
</template>