<script setup lang="ts">
import DatabaseNames from "@/constants/DatabaseNames";

const showTool: Ref<Boolean> = ref(false)

const route = useRoute()
const menteeId: any = route.params.id

const router = useRouter();

const goBack = () => {
    router.back();
};

// Mentee Information
const useMentees = useMenteeStore();

const menteeInfo = await useMentees.fetchMentee(menteeId);

//

const useEvaluations = useEvalDataStore();

const menteeEvals = await useEvaluations.fetchMenteeEvals(menteeId);

//
const viewSession = (session: string, scoreId: string) => {
    navigateTo('/reports/partial/' + session + '/' + scoreId)
}

</script>
<template>
      <SharedBorderedNavBar>
            <template #lead>
                <div v-show="!showTool">
                    <!-- <NuxtLink :to="Routes.PREVIEW.path"> -->
                    <div class="pr-5 text-blue-500 cursor-pointer" @click="goBack">
                        <UIcon name="i-heroicons-arrow-small-left" />
                        Back
                    </div>
                    <!-- </NuxtLink> -->
                </div>
                <div v-show="showTool">
                    <div class="pr-5 text-blue-500 cursor-pointer" @click="showTool = false">
                        <UIcon name="i-heroicons-arrow-small-left" />
                    </div>
                </div>
                <!-- 
            <div>
                <span class=" text-gray-400"><strong>Evaluating</strong></span> | <span class=" text-sky-700"> {{
                    selectedTool.label }}</span>
            </div> -->
            </template>
        </SharedBorderedNavBar>
        <div class="py-2.5" />
        <UContainer>
            <UCard>
                <template #header>
                    <div class="font-semibold text-orange-500">
                        {{ menteeInfo.firstname }} {{ menteeInfo?.middlename }} {{ menteeInfo.lastname }}
                    </div>
                </template>

                <div class="grid grid-cols-2 gap-5">
                    <div class="font-semibold">
                        Gender
                    </div>
                    <div>
                        {{ menteeInfo.gender }}
                    </div>
                </div>
                <div class="py-2.5" />
                <div class="grid grid-cols-2 gap-5">
                    <div class="font-semibold">
                        District
                    </div>
                    <div>
                        {{ menteeInfo.district }}
                    </div>
                </div>
                <div class="py-2.5" />
                <div class="grid grid-cols-2 gap-5">
                    <div class="font-semibold">
                        Facility
                    </div>
                    <div>
                        {{ menteeInfo.facility }}
                    </div>
                </div>
                <div class="py-2.5" />
                <div class="grid grid-cols-2 gap-5">
                    <div class="font-semibold">
                        Profession
                    </div>
                    <div>
                        {{ menteeInfo.profession }}
                    </div>
                </div>
            </UCard>
            <!-- <pre>
                {{ menteeEvals }}
            </pre> -->
            <div class="py-2.5" />
            <div>
                The provider has gone through <span class="text-sky-700 font-semibold italic">{{ menteeEvals.length }} </span> disease evaluations
            </div>
            <div v-for="evaluation in menteeEvals">
                <div class="py-2.5">
                     <ReportMenteeEvals :evaluation="evaluation" />
                </div>
            </div>
            <div class="py-2.5" />
        </UContainer>
</template>