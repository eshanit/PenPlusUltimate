<script setup lang="ts">
import ScoreCards from '../shared/ScoreCards.vue';

type ScoreCount = {
  [key: string]: number;
};

const props = defineProps<{
    tool: string,
    sessionIndex: number,
    scoreCounts: ScoreCount,
    evaluation: any
}>()



const countScores = useScoreCount(props.evaluation.sessions[`session_${props.sessionIndex}`].evalItemScores)

const percScores = computed(() => {
    const total = Object.values(props.scoreCounts).reduce((sum, value) => sum + value, 0);
  const percentages: ScoreCount = {};

  for (const key in props.scoreCounts) {
    percentages[key] = parseFloat(((props.scoreCounts[key] / total) * 100).toFixed(2)); // Convert to number
  }

  return percentages;
})


//
const showAll: Ref<Boolean> = ref(true)
const showOne: Ref<Boolean> = ref(false)
const showTwo: Ref<Boolean> = ref(false)
const showThree: Ref<Boolean> = ref(false)

const switchScoreList = (score: number) => {
    switch (score) {
        case 1:
            showAll.value = false
            showOne.value = true
            showTwo.value = false
            showThree.value = false
            break;
        case 2:
            showAll.value = false
            showOne.value = false
            showTwo.value = true
            showThree.value = false
            break;
        case 3:
            showAll.value = false
            showOne.value = false
            showTwo.value = false
            showThree.value = true
            break;
        // Add more cases as needed
        default:
            showAll.value = true
            showOne.value = false
            showTwo.value = false
            showThree.value = false
    }
}

</script>
<template>
    <div class="">
        <div class="grid grid-cols-3 gap-5">
            <div @click="switchScoreList(1)">
                <UCard
                    class="flex-grow text-center text-red-500 rounded-lg hover:bg-red-100 hover:shadow-lg  hover:text-white cursor-pointer">

                    <div class="border-b">Number of 1's</div>
                    <div class="text-5xl ">{{ countScores["1"] }}</div>

                </UCard>
                <div class="border-b-8 border-red-500 rounded-lg py-1" v-if="showOne" />
            </div>
            <div @click="switchScoreList(2)">
                <UCard
                    class="flex-grow text-center text-yellow-500 rounded-lg hover:bg-orange-100 hover:shadow-lg  hover:text-white cursor-pointer">

                    <div class="border-b">Number of 2's</div>
                    <div class="text-5xl ">{{ countScores["2"] }}</div>

                </UCard>
                <div class="border-b-8 border-yellow-500 rounded-lg py-1" v-if="showTwo" />
            </div>
            <div @click="switchScoreList(3)">
                <UCard
                    class="flex-grow text-center text-green-500 rounded-lg hover:bg-green-100 hover:shadow-lg  hover:text-white cursor-pointer">

                    <div class="border-b">Number of 3's</div>
                    <div class="text-5xl ">{{ countScores["3"] }}</div>

                </UCard>
                <div class="border-b-8 border-green-500 rounded-lg py-1" v-if="showThree" />
            </div>
        </div>
        <div class="grid grid-cols-3 gap-5">
            <div>

            </div>
            <div>
                <div class=" pb-10" />
                <div v-if="showAll == true">
                    <ChartsMenteeScorePie :tool="props.tool" :score-counts="props.scoreCounts" />
                </div>
                <div v-if="showOne == true">
                        <UMeter icon="i-clipboard-document-check" color="red" :value="percScores['1']"  label="% of 1s" size="2xl" indicator  />
                   
                </div>
                <div v-if="showTwo == true">
                        <UMeter icon="i-clipboard-document-check" color="yellow" :value="percScores['2']"  label="% of 2s" size="2xl" indicator  />
                   
                </div>
                <div v-if="showThree == true">
                        <UMeter icon="i-clipboard-document-check" color="green" :value="percScores['3']"  label="% of 3s" size="2xl" indicator  />
                   
                </div>


            </div>
            <div>

            </div>
        </div>
        <div class="py-2.5" />
        <div v-if="!showAll">
            <p class="py-1">Click button below to view all scores</p>
            <UButton class="" label="View All" @click="switchScoreList(4)" />
        </div>
    </div>
    <div class="py-5" />

    <div v-if="showOne == true">
        <ScoreCards :tool="props.tool" :session-index="props.sessionIndex" :evaluation="props.evaluation" score="1" />
    </div>
    <div v-if="showTwo == true">
        <ScoreCards :tool="props.tool" :session-index="props.sessionIndex" :evaluation="props.evaluation" score="2" />
    </div>
    <div v-if="showThree == true">
        <ScoreCards :tool="props.tool" :session-index="props.sessionIndex" :evaluation="props.evaluation" score="3" />
    </div>
    <div v-if="showAll == true">
        <ScoreCards :tool="props.tool" :session-index="props.sessionIndex" :evaluation="props.evaluation" score="all" />
    </div>

</template>