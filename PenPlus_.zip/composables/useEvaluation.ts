import evaluationItemData from "@/data/evaluationItemData"

export const useEvaluation = () => {
  return evaluationItemData
}
