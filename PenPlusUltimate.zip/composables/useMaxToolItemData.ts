export function useMaxToolItemData(data: any) {

    const maxScores = {};
    if( data.length > 0) {
        
        for (const evaluation of data) {
            for (const sessionKey in evaluation.sessions) {
              const session = evaluation.sessions[sessionKey];
              if (session) {
                const { evalDate, evalItemScores } = session;
                for (const item of evalItemScores) {
                  const { name, score } = item;
                  const scoreValue = parseInt(score);
          
                  if (!maxScores[name] || scoreValue > maxScores[name].score) {
                    maxScores[name] = { date: evalDate, session: sessionKey, name, score: scoreValue };
                  }
                }
              }
            }
          }

          const result = Object.values(maxScores);

          return result
    }

    return;
      
}