<script setup lang="ts">

interface PieData {
    [key: string]: number; // This allows dynamic keys with string type
}

const props = defineProps<{
    pieData:PieData
}>()

const chartOptions = {
    series: Object.values(props.pieData),
    options: {
        chart: {
            width: 380,
            type: 'pie',
        },
        labels: Object.keys(props.pieData),
        responsive: [{
            breakpoint: 480,
            options: {
                chart: {
                    width: 200
                },
                legend: {
                    position: 'bottom'
                }
            }
        }]
    }
}

</script>
<template>
     <apexchart type="pie" width="380" :options="chartOptions.options" :series="chartOptions.series"></apexchart>
</template>