<script setup lang="ts">
import DatabaseNames from "@/constants/DatabaseNames";
import type IFinalEvaluation from "~/interfaces/IFinalEvaluation";
import evaluationItemData from "@/data/evaluationItemData";

const route = useRoute()
const gender: any = route.params.gender

const router = useRouter();

const goBack = () => {
    router.back();
};

//evaluations
const useEvaluations = useEvalDataStore();

const completedEvals: IFinalEvaluation[] = await useEvaluations.fetchEvaluationScores(DatabaseNames.COMPLETED_EVALUTATIONS);

const newGender = computed(() => {

    let genderx = 'Other'

    if (gender == 'Males') {
        genderx = 'Male'
    } else if (gender == 'Females') {
        return genderx = 'Female'
    } else {
        genderx = 'Other'
    }

    return genderx

})

const genderEvaluations = computed(() => {
    return completedEvals.filter((e) => {
        return e.mentee.gender == newGender.value
    })
})

const evaluationStats = useEvaluationStats(genderEvaluations.value)

const countSessions = useGenderSessionsCompleted(newGender.value, evaluationStats)

//
/// tools
const tools = useTools;

const toolEvaluationCounts = computed(() => {
    let counts: any[] = []
    tools.forEach((tool) => {
        counts.push({
            tool: tool.label,
            total: useCountToolSessionsCompleted(tool.name, evaluationStats).totalCompletedCount,
            totalSessions: useCountToolSessionsCompleted(tool.name, evaluationStats).totalCompletedSessions
        })
    });

    return counts;
})

// Finding highest totals
const maxToolTotal = Math.max(...toolEvaluationCounts.value.map(tool => tool.total));
const highestToolTotals = toolEvaluationCounts.value.filter(tool => tool.total === maxToolTotal);

// Finding lowest totals
const minToolTotal = Math.min(...toolEvaluationCounts.value.map(tool => tool.total));
const lowestToolTotals = toolEvaluationCounts.value.filter(tool => tool.total === minToolTotal);

const isToolHighestOpen = ref(false)
const isToolLowestOpen = ref(false)

const selectedTool = ref('diabetes')

//showTable
const showFacilitySessionEvalsTable = ref(false)

const latestEvalScores = useLatestSessionEvals(genderEvaluations.value)

const latestEvalScoresCountsPerTool = (tool: string) => {

    const results = latestEvalScores.filter((el: any) => el.tool == tool)

    const scores = results.map(el => el.scores).flat()

    const result: any = {};

    scores.forEach((item) => {

        const name = item.name;
        const score = Number(item.score);
        const scoreKey = `score${score}`;

        // Initialize the name entry if it doesn't exist
        if (!result[name]) {
            result[name] = { score1: 0, score2: 0, score3: 0 };
        }

        // Increment the appropriate score count if valid (1-3)
        if (result[name][scoreKey] !== undefined) {
            result[name][scoreKey]++;
        }
    });

    return result

}

//
const toolData = computed(() => {
    const result = evaluationItemData.filter((t: { tool: string; }) => t.tool == selectedTool.value);

    const newResult: any[] = [];

    const items: any[] = [];

    result.forEach((r: { evaluationItems: any[]; }) => {


        r.evaluationItems.forEach((e) => {

            const counts = latestEvalScoresCountsPerTool(selectedTool.value)

            items.push({
                item: e.number,
                title: e.title,
                numberof3: counts[e.number]?.score3 ?? null,
                numberof2: counts[e.number]?.score2 ?? null,
                numberof1: counts[e.number]?.score1 ?? null,
            })
        })

    })

    return items

})


</script>
<template>
    <SharedBorderedNavBar>
        <template #lead>
            <!-- <NuxtLink :to="Routes.COMPLETED_EVALUATIONS.path"> -->
            <div class="pr-5 text-blue-500 cursor-pointer" @click="goBack">
                <UIcon name="i-heroicons-arrow-small-left" />
            </div>
            <!-- </NuxtLink> -->
            <div>
                <span class=" text-gray-400"><strong>Mentees</strong></span> | <span class=" text-orange-500">
                    Reporting and Analysis </span>
                | <span class=" text-green-500">
                    {{ gender }}
                </span>
            </div>
        </template>
    </SharedBorderedNavBar>

    <UContainer>
        <div class="py-5" />
        <div class="text-sky-500 text-5xl">
            {{ gender }}
        </div>
        <div class="py-5" />

        <div class="grid grid-cols-2 gap-5">
            <div>
                <UCard>
                    <template #header>
                        <div class="text-center">Total Evaluations</div>
                    </template>
                    <div class="text-center text-3xl text-sky-500">
                        {{ countSessions.totalCompletedCount }}
                    </div>
                </UCard>
            </div>
            <div>
                <UCard>
                    <template #header>
                        <div class="text-center">Total Sessions</div>
                    </template>
                    <div class="text-center text-3xl text-red-500">
                        {{ countSessions.totalCompletedSessions }}
                    </div>
                </UCard>
            </div>
        </div>
        <div class="py-2.5" />
        <div class="grid grid-cols-2 gap-5">
            <div>
                <UCard>
                    <template #header>
                        <div class="text-center"><span class="font-bold">Most</span> evaluated Tool(s): <span
                                class="italic">
                                <div class="">
                                    <span class="italic font-bold" v-if="highestToolTotals.length == 1">
                                        ({{ maxToolTotal }} Evaluations)
                                    </span>
                                    <span v-else-if="highestToolTotals.length > 0">
                                        ({{ maxToolTotal }} Evaluation(s) each)
                                    </span>
                                </div>
                            </span>
                        </div>

                    </template>
                    <div class="text-5xl text-lime-500 font-semibold flex justify-center">
                        <span v-if="highestToolTotals.length == 1">
                            {{ highestToolTotals[0].tool }}
                        </span>
                        <span v-else-if="highestToolTotals.length > 0">
                            <UButton variant="soft" color="lime" @click="isToolHighestOpen = true">
                                {{ highestToolTotals.length }} Tools
                            </UButton>
                        </span>
                        <span v-else>
                            -
                        </span>
                    </div>

                </UCard>
            </div>
            <div>
                <UCard>
                    <template #header>
                        <div class="text-center"><span class="font-bold">Least</span> evaluated Tool(s): <span
                                class="italic">
                                <div class="">
                                    <span class="italic font-bold" v-if="lowestToolTotals.length == 1">
                                        ({{ minToolTotal }} Evaluation)
                                    </span>
                                    <span v-else-if="lowestToolTotals.length > 1">
                                        ({{ minToolTotal }} Evaluations each)
                                    </span>
                                </div>
                            </span>
                        </div>

                    </template>
                    <div class="text-5xl text-orange-500 font-semibold flex justify-center">
                        <span v-if="lowestToolTotals.length == 1">
                            {{ lowestToolTotals[0].tool }}
                        </span>
                        <span v-else-if="lowestToolTotals.length > 1">
                            <UButton variant="soft" color="orange" @click="isToolLowestOpen = true">
                                {{ lowestToolTotals.length }} Tools
                            </UButton>
                        </span>
                        <span v-else>
                            -
                        </span>
                    </div>

                </UCard>
            </div>
        </div>
        <UDivider label="Tool Analysis" :ui="{ label: 'text-primary-500 dark:text-primary-400' }" class="py-5" />

        <div>
            Select tool to view score counts
        </div>
        <div class="py-5 w-1/3">
            <!-- {{ selectedTool }} -->
            <USelect v-model="selectedTool" :options="tools" option-attribute="label" value-attribute="name" />
        </div>

        <div class=" pb-10">
            <div v-if="Object.values(latestEvalScoresCountsPerTool(selectedTool)).length != 0">
                <TablesAGtablesDistrictsToolScores :tool-data="toolData" />
            </div>
            <div v-else>
                No evaluations recorded for <span class="font-bold"> {{ selectedTool }}</span> for {{ gender }}
                district.
            </div>

        </div>
    </UContainer>
    <USlideover v-model="isToolHighestOpen">
        <div class="p-4 flex-1">
            <UButton color="gray" variant="ghost" size="sm" icon="i-heroicons-x-mark-20-solid"
                class="flex sm:hidden absolute end-5 top-5 z-10" square padded @click="isToolHighestOpen = false" />

            <div class=" pt-10 pb-5">
                Most evaluated tools by <span class="font-bold text-lime-500">{{ gender }}</span>
            </div>
            <div class="p-5 border rounded-lg">
                <div class="grid grid-cols-2 gap-5 font-bold bg-lime-400 px-2">
                    <div>
                        Tool
                    </div>
                    <div>
                        Number of Evaluations
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-5 py-2.5 border-t cursor-pointer px-2 hover:bg-gray-100"
                    v-for="tool in highestToolTotals">
                    <div>
                        {{ tool.tool }}
                    </div>
                    <div class="text-center">
                        {{ tool.total }}
                    </div>
                </div>
            </div>
        </div>
    </USlideover>
    <USlideover v-model="isToolLowestOpen">
        <div class="p-4 flex-1">
            <UButton color="gray" variant="ghost" size="sm" icon="i-heroicons-x-mark-20-solid"
                class="flex sm:hidden absolute end-5 top-5 z-10" square padded @click="isToolLowestOpen = false" />

            <div class=" pt-10 pb-5">
                Least evaluated tools by <span class="font-bold text-orange-500">{{ gender }}</span>
            </div>
            <div class="p-5 border rounded-lg">
                <div class="grid grid-cols-2 gap-5 font-bold bg-orange-400 px-2">
                    <div>
                        Tool
                    </div>
                    <div>
                        Number of Evaluations
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-5 py-2.5 border-t cursor-pointer px-2 hover:bg-gray-100"
                    v-for="tool in lowestToolTotals">
                    <div>
                        {{ tool.tool }}
                    </div>
                    <div class="text-center">
                        {{ tool.total }}
                    </div>
                </div>
            </div>
        </div>
    </USlideover>
</template>