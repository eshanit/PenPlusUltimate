<script setup lang="ts">
import type  IEvaluationCounts from "@/interfaces/IEvaluationCounts"

const props = defineProps<{
    evalCounts: IEvaluationCounts
}>()

const chartData = {
    series: [props.evalCounts.oneCompletedCount, props.evalCounts.twoCompletedCount, props.evalCounts.allCompletedCount],
    options: {
        title: {
    text: '% Evaluations',
    align: 'left',
    margin: 10,
    offsetX: 0,
    offsetY: 0,
    floating: false,
    style: {
      fontSize:  '18px',
      fontWeight:  'bold',
      fontFamily:  undefined,
      color:  '#263238'
    },
},
        chart: {
            width: 280,
            type: 'pie',
        },
        labels:['1-session', '2-sessions', '3-sessions'],
        responsive: [{
            breakpoint: 280,
            options: {
                chart: {
                    width: 200
                },
                legend: {
                    position: 'bottom'
                }
            }
        }]
    }
}


</script>
<template>
    <div>
        <apexchart width="" type="pie" :options="chartData.options" :series="chartData.series"></apexchart>
    </div>
</template>