<script setup lang="ts">
import { computedAsync } from "@vueuse/core";
import DatabaseNames from "@/constants/DatabaseNames";

const router = useRouter();

const goBack = () => {
    router.back();
};
//
const showToolChartPerc: Ref<Boolean> = ref(false)

//evaluations
const useEvaluations = useEvalDataStore();

const completedEvals = await useEvaluations.fetchEvaluationScores(DatabaseNames.COMPLETED_EVALUTATIONS);

const evaluationStats = useEvaluationStats(completedEvals)

//progress tracking
const tools = useTools


const countToolSessions = computed(() => {
    const arr: any[] = []
    tools.forEach((tool) => {
        const countSessions = useCountToolSessionsCompleted(tool.name, evaluationStats)
        arr.push({
            label: tool.label,
            name: tool.name,
            fiveCompleted: countSessions.allCompletedCount,
            fourCompleted: countSessions.fourCompleted,
            threeCompleted: countSessions.threeCompleted,
            twoCompleted: countSessions.twoCompletedCount,
            oneCompleted: countSessions.oneCompletedCount,
            totalCompleted: countSessions.totalCompletedCount
        })
    });

    return arr
})

//score counts


const scoreCounts = computedAsync(async () => {
    const evalArr = await Promise.all(
        tools.map(async (tool) => {
            const toolEvals = await useEvaluations.fetchToolEvals(tool.name);
            return {
                name: tool.label,
                counts: useNumResponsesPerTool(toolEvals)
            };
        })
    );

    return evalArr;
});

const showAggregateTable: Ref<Boolean> = ref(true)


</script>
<template>
    <SharedBorderedNavBar>
        <template #lead>
            <!-- <NuxtLink :to="Routes.COMPLETED_EVALUATIONS.path"> -->
            <div class="pr-5 text-blue-500 cursor-pointer" @click="goBack">
                <UIcon name="i-heroicons-arrow-small-left" />
            </div>
            <!-- </NuxtLink> -->
            <div>
                <span class=" text-gray-400"><strong>Tools</strong></span> | <span class=" text-orange-500">
                    Analysis</span>
            </div>
        </template>
    </SharedBorderedNavBar>
    <div ref="NCD Tool Eval" class="py-10">

        <UContainer>
            <UCard class="bg-green-50">
                <template #header>
                    <div class="font-bold pb-5 text-orange-500">Evaluations by NCD Tool/Disease:</div>
                </template>
                <div class="text-sky-900">
                    The charts below show the number of evaluation-sessions done for each disease. Its broken down by
                    number
                    of evaluations with
                    1 session, 2 sessions, 3 sessions, 4 sessions and 5 sessions. A completed evaluation is one with 5
                    sessions.
                </div>
                <div class="py-5">
                    <div v-if="showToolChartPerc">
                        <div class="pb-2.5">
                            <UButton @click="showToolChartPerc = false">
                                View Counts
                            </UButton>
                        </div>
                        <ChartsDashboardToolsStackedPerc :count-tool-sessions="countToolSessions" />

                    </div>
                    <div v-else>
                        <div class="pb-2.5">
                            <UButton @click="showToolChartPerc = true">
                                View Percentages
                            </UButton>
                        </div>
                        <ChartsDashboardToolsStacked :count-tool-sessions="countToolSessions" />
                    </div>
                </div>
                <div>
                    <TablesAGtablesDashboardToolEvaluations :evaluation-stats="evaluationStats" />
                </div>
            </UCard>

            <UDivider label="Competency Response Count" class="py-10" />


<div v-if="showAggregateTable">
    <div>
        <p class="pb-1.5">
            The table below shows the number of scores per disease evaluated on. To see a comprehensive
            breakdown by
            each
            evaluation item, click this button below:

        </p>

        <div>
            <UButton label="View Itemized" @click="showAggregateTable = false" />
        </div>
    </div>
    <div class="py-2.5" />
    <TablesAggregateToolScoreCounts :tool-evals="completedEvals"  />
</div>
<div v-else>
    <div>
        <p class="pb-1.5">
            The table below shows the number of scores per disease evaluated on. To see a summarized
            breakdown , click this button below:

        </p>

        <div>
            <UButton label="View Summarized" color="sky" @click="showAggregateTable = true" />
        </div>
    </div>
    <div class="py-2.5" />
    <TablesToolScoreCounts :tool-evals="completedEvals"  />

</div>


            <!-- <pre>
            {{ scoreCounts }}
        </pre> -->
        </UContainer>
    </div>
</template>