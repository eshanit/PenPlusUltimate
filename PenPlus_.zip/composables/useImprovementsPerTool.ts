import type ISession from "~/interfaces/ISession";

export function useImprovementsPerTool(toolsEvals: any) {

    const improvements = ref<{ tool: string; mentee: string; improvement: boolean | string }[]>([]);

    toolsEvals.forEach((evaluation: { tool: any; mentee: { firstname: any; lastname: any; }; sessions: ISession; }) => {
        const tool = evaluation.tool;
        const menteeFullName = `${evaluation.mentee.firstname} ${evaluation.mentee.lastname}`;
        const sessions = evaluation.sessions;

        // Check if the tool is 'echo'
        if (tool === 'echo') {
            return; // Skip for 'echo'
        }

        // Calculate mean scores for sessions
        const sessionScores: { [key: string]: number } = {};
        let sessionCount = 0;

        for (const [sessionKey, session] of Object.entries(sessions)) {
            if (session && session.evalItemScores) {
                const scores = session.evalItemScores.map((item: { score: string; }) => parseFloat(item.score));
                const meanScore = scores.reduce((a: any, b: any) => a + b, 0) / scores.length;

                sessionScores[sessionKey] = meanScore;
                sessionCount++;
            }
        }

        // Compare scores based on session count
        if (sessionCount < 2) {
            improvements.value.push({ tool, mentee: menteeFullName, improvement: '-' });
        } else if (sessionCount === 2) {
            const session1Score = sessionScores['session_1'];
            const session2Score = sessionScores['session_2'];
            if (session1Score == 3 && session2Score == 3) {
                improvements.value.push({ tool, mentee: menteeFullName, improvement: 'Max Score' });
            }
            improvements.value.push({ tool, mentee: menteeFullName, improvement: session2Score > session1Score });
        } else if (sessionCount >= 3) {
            const session2Score = sessionScores['session_2'];
            const session3Score = sessionScores['session_3'];

            if (session2Score == 3 && session3Score == 3) {
                improvements.value.push({ tool, mentee: menteeFullName, improvement: 'Max Score' });
            }
            improvements.value.push({ tool, mentee: menteeFullName, improvement: session3Score > session2Score });
        }
    });

    return improvements.value;
}