import pouchDBConnect from "@/utilities/pouchDbConnect";


const useReplicateFromCouchDB = async (databaseName: string ): Promise<any> => {

const toast = useToast()
const config = useRuntimeConfig();
const couchDBUsername = config.public.couchDBUsername;
const couchDBPassword = config.public.couchDBPassword;

  console.log('couch:', couchDBUsername, couchDBPassword, config.public.couchDBUrl )

    //setup
    const localDB = pouchDBConnect(databaseName)
    const remoteDB = pouchDBConnect(`${config.public.couchDBUrl}/` + databaseName, {
        skip_setup: true,
      })
    
    //sync
   return remoteDB.logIn(couchDBUsername, couchDBPassword).then(() => {
      return   localDB.replicate.from(remoteDB, {
          live: true,
          retry: true,
        })
          .on("paused", () => {
            console.log("complete: ",config.public.couchDBUrl, remoteDB , localDB);
            if (databaseName === 'scores') {
              toast.add({
                title: `You have successifully synced ${databaseName}`,
                color: 'sky'
              })
    
            }
           return true;
          })
          .on("denied", (denied) => {
            console.log(databaseName, denied);
            toast.add({
                title: `Syncing ${databaseName} ${couchDBUsername} ${ couchDBPassword} has been denied`,
                color: 'rose'
              })
          })
          .on("error", (err: any) => {
            console.error(databaseName, err);
            toast.add({
                title: `Syncing ${databaseName} ${couchDBUsername} ${ couchDBPassword} has an error, please contact admin`,
                color: 'rose'
              })
          });
      })
      .catch((err: any) => {
        console.error("Remote Login Error", err);
        toast.add({
            title: `Syncing ${databaseName} ${couchDBUsername} ${ couchDBPassword} has been denied, please check your credentials`,
            color: 'rose'
          })
      });
      
    
    }
    
    export default useReplicateFromCouchDB;