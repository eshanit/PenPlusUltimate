<script setup lang="ts">
import type ITools from '@/interfaces/ITools';
import Routes from '@/constants/Routes';

const user = useUserDetails;

</script>

<template>
    <div class="">
        <SharedNavBar>
            <template #lead>
                <h1 class="text-lg font-bold text-center">NCD Pen Plus Monitoring</h1>
            </template>
        </SharedNavBar>

        <UContainer class="p-4 h-screen flex flex-col justify-center">
            <!-- <div class="text-center mb-4">
                Welcome,
                <span class="text-sky-700 font-bold">{{ user.firstname }} {{ user.lastname }}</span>
            </div> -->
      
            <div class="grid grid-cols-3 gap-5">
                <div class="text-center">
                    <div>
                        To start evaluating providers, click on the button below
                    </div>
                    <div class="py-5" />
                    <NuxtLink :to="Routes.COMPLETED_EVALUATIONS.path">
                        <div class="flex justify-center">
                            <UButton color="sky" variant="soft" label="Start Evaluation" size="xl" block />
                        </div>
                    </NuxtLink>
                </div>
                <UDivider orientation="vertical" />
                <div class="text-center">
                    <div>
                        To sync data manually, click on the button below
                    </div>
                    <div class="py-5" />
                    <NuxtLink :to="Routes.SYNC">
                        <div class="flex justify-center">
                            <UButton color="orange" variant="soft" label="Sync Data" size="xl" block />
                        </div>
                    </NuxtLink>
                </div>
            </div>


            <!-- <div class="flex flex-col items-center h-full gap-5">
                <div class="flex flex-col items-center justify-center cursor-pointer">
                    <NuxtLink :to="Routes.COMPLETED_EVALUATIONS.path">
                        <SharedTwCard>
                            <template #body>
                                <div class=" font-bold text-orange-500">
                                    Start Evaluating
                                </div>
                            </template>
                        </SharedTwCard>
                    </NuxtLink>
                </div>
                <div class="flex flex-col items-center justify-center cursor-pointer">
                    <NuxtLink :to="Routes.SYNC">
                        <SharedTwCard>
                            <template #body>
                                <div class="font-bold text-cyan-500">
                                    Sync Data
                                </div>
                            </template>
                        </SharedTwCard>
                    </NuxtLink>
                </div>
            </div> -->
        </UContainer>
    </div>
</template>

<style scoped>
/* Additional custom styles */

.text-pretty {
    color: #3B82F6;
    /* Sky color */
}

.icon-size {
    width: 100%;
    /* Fill the container width */
    height: auto;
    /* Maintain aspect ratio */
    max-height: 100px;
    /* Limit height for larger icons */
}

@media (max-width: 768px) {
    .text-lg {
        font-size: 1.5rem;
        /* Larger text on mobile */
    }

    .icon-size {
        max-height: 80px;
        /* Adjust icon size for smaller screens */
    }
}
</style>