<script setup lang="ts">
import { format } from 'date-fns'
import Routes from "@/constants/Routes";
import LocalStorageKeys from "@/constants/LocalStorageKeys";


const evalData = useEvaluation()
const route = useRoute()
const tool = route.params.tool

const showTool: Ref<Boolean> = ref(false)
// const selectedTool: Ref<any> = ref()
// selectedTool.value = useProcessLocalStorage().retrieve(LocalStorageKeys.TOOL)
const evalSession: any = useProcessLocalStorage().retrieve(LocalStorageKeys.EVALUATION_SESSION)

const menteeData: any = useProcessLocalStorage().retrieve(LocalStorageKeys.EVALUATED_MENTEE)


const evalItems = computed(() => {
    return evalData.find((e) => e.tool === tool)
})





const now = new Date(Date.now());
const formattedDate = format(now, 'MMMM dd, yyyy HH:mm:ss'); // Example format




const router = useRouter();

const goBack = () => {
  router.back();
};



</script>
<template>
    <SharedBorderedNavBar>
        <template #lead>
            <div v-show="!showTool">
                <!-- <NuxtLink :to="Routes.PREVIEW.path"> -->
                    <div class="pr-5 text-blue-500 cursor-pointer" @click="goBack">
                        <UIcon name="i-heroicons-arrow-small-left" />
                    </div>
                <!-- </NuxtLink> -->
            </div>
            <div v-show="showTool">
                <div class="pr-5 text-blue-500 cursor-pointer" @click="showTool = false">
                    <UIcon name="i-heroicons-arrow-small-left" />
                </div>
            </div>

            <div>
                <span class=" text-gray-400"><strong>Evaluating</strong></span> | <span class=" text-sky-700"> {{
                    tool }}</span>
            </div>
        </template>
    </SharedBorderedNavBar>
    <UContainer>
        <div>
            <div class="flex gap-4 py-2.5">
                <div class=" text-sky-600">
                    <strong>Mentee Name:</strong>
                </div>
                <div>
                    {{ menteeData.firstname }} {{ menteeData.lastname }}
                </div>
            </div>
            <div class="flex gap-4 py-2.5">
                <div class=" text-sky-600">
                    <strong>Session:</strong>
                </div>
                <div>
                    {{ evalSession }}
                </div>
            </div>
            <div class="flex gap-4 py-2.5">
                <div class=" text-sky-600">
                    <strong>Date:</strong>
                </div>
                <div>
                    {{ formattedDate }}
                </div>
            </div>
        </div>
        <!--form-->
       
            <FormsMainEvaluation :mentee-data="menteeData" :selected-tool="tool" :evaluation-items="evalItems?.evaluationItems" :cut-off="evalItems?.numItems" />
    
     
    </UContainer>


</template>