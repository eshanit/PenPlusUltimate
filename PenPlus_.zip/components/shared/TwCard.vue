<script setup lang="ts">
</script>
<template>
  <div class=" bg-white rounded-2xl shadow-xl p-5">
    <slot name="body"></slot>
  </div>
</template>