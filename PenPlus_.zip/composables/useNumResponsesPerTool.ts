import type ISession from "~/interfaces/ISession";

export function useNumResponsesPerTool(toolsEvals: any) {

const scoreCounts = ref<{ tool: string; scores: { [key: string]: { [key: number]: number } } }[]>([]);

toolsEvals.forEach((evaluation: { tool: any; mentee: { firstname: any; lastname: any; }; sessions: ISession; }) => {
  const tool = evaluation.tool;
  const sessions = evaluation.sessions;

  // Determine the final session
  const finalSessionKey = sessions.session_3 ? 'session_3' : (sessions.session_2 ? 'session_2' : 'session_1');
  const finalSession = sessions[finalSessionKey];

  if (finalSession && finalSession.evalItemScores) {
    const scoreDistribution: { [key: string]: { [key: number]: number } } = {};

    finalSession.evalItemScores.forEach((item: { score: string; name: any; }) => {
      const score = parseInt(item.score, 10); // Ensure score is parsed as an integer
      const itemName = item.name;

      // Initialize score counts if not already done
      if (!scoreDistribution[itemName]) {
        scoreDistribution[itemName] = { 1: 0, 2: 0, 3: 0 };
      }

      // Increment the count for scores 1, 2, or 3
      if (score >= 1 && score <= 3) {
        scoreDistribution[itemName][score]++;
      } else {
        console.warn(`Unexpected score ${item.score} for item ${itemName}`); // Debug info
      }
    });

    // Store the results for the tool
    scoreCounts.value.push({ tool, scores: scoreDistribution});

  }
});

const result = {};

scoreCounts.value.forEach(({ tool, scores }) => {
    if (!result[tool]) {
      result[tool] = {};
    }

    for (const competency in scores) {
      if (!result[tool][competency]) {
        result[tool][competency] = { ones: 0, twos: 0, threes: 0 };
      }

      const score = scores[competency];
      result[tool][competency].ones += score[1] || 0;
      result[tool][competency].twos += score[2] || 0;
      result[tool][competency].threes += score[3] || 0;
    }
  });

  return result;
return scoreCounts;
}