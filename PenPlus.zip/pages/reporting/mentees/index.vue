<script setup lang="ts">
import DatabaseNames from "@/constants/DatabaseNames";
import type IFinalEvaluation from "~/interfaces/IFinalEvaluation";


const router = useRouter();

const goBack = () => {
    router.back();
};
//
//mentees
const useMentees = useMenteeStore();

const mentees: any = await useMentees.fetchMentees();

//evaluations
const useEvaluations = useEvalDataStore();

const completedEvals: IFinalEvaluation[] = await useEvaluations.fetchEvaluationScores(DatabaseNames.COMPLETED_EVALUTATIONS);

const genderEvaluations = (profession: string) => {

    return completedEvals.filter((e) => {
        return e.mentee.profession == profession
    })

}

//const evaluationStats = useEvaluationStats(completedEvals)

const genderCounts = computed(() => {
    const males = mentees.filter((m: any) => m.gender == 'Male')
    const females = mentees.filter((m: any) => m.gender == 'Female')
    const Other = mentees.filter((m: any) => m.gender == 'Other')

    return {
        Males: males.length,
        Females: females.length,
        Other: Other.length
    }
})

const genderReport = (gender: string): void => {
    navigateTo('/Reporting/Mentees/Gender/'+ gender)
}
//

const professions: string[] = Array.from(new Set(mentees.map((m: { profession: any; }) => m.profession)))

//

interface ProfessionCounts {
    [key: string]: number; // This allows dynamic keys with string type
}

const professionCounts = computed<ProfessionCounts>(() => {
    const count: ProfessionCounts = {};
    professions.forEach((p) => {
        count[p] = mentees.filter((m: { profession: string; }) => m.profession === p).length;
    });

    return count;
});



</script>
<template>
    <SharedBorderedNavBar>
        <template #lead>
            <!-- <NuxtLink :to="Routes.COMPLETED_EVALUATIONS.path"> -->
            <div class="pr-5 text-blue-500 cursor-pointer" @click="goBack">
                <UIcon name="i-heroicons-arrow-small-left" />
            </div>
            <!-- </NuxtLink> -->
            <div>
                <span class=" text-gray-400"><strong>Mentees</strong></span> | <span class=" text-orange-500">
                    Reporting and Analysis</span>
            </div>
        </template>
    </SharedBorderedNavBar>

    <UContainer>



        <!-- <SelectedMentees :mentees="mentees" :evaluations="completedEvals" /> -->
        <TablesAGtablesMenteesAllList :mentees="mentees" :evaluations="completedEvals" />

        <UDivider label="Mentees by gender" class="py-5" />

        <div class="mt-12 grid grid-cols-2 gap-5">
            <div>
                <ChartsSharedPie :pie-data="genderCounts" />
            </div>
            <div class="">
                <div class="overflow-hidden rounded-lg shadow-md border border-gray-200">
                    <div class="bg-gray-100 grid grid-cols-3 font-bold p-4">
                        <div>Gender</div>
                        <div>Count</div>
                        <div>View</div>
                    </div>
                    <div v-for="(count, gender) in genderCounts" :key="gender"
                        class="grid grid-cols-3 border-t py-2.5 px-4">
                        <div>{{ gender }}</div>
                        <div>{{ count }}</div>
                        <div>
                            <UButton color="orange" variant="soft" @click="genderReport(gender)">
                                Report
                            </UButton>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <UDivider label="Mentees by profession" class="py-5" />


        <div class="mt-12 grid grid-cols-2 gap-5">
            <div>
                <ChartsSharedPie :pie-data="professionCounts" />
            </div>
            <div class="">
                <div class="overflow-hidden rounded-lg shadow-md border border-gray-200">
                    <div class="bg-gray-100 grid grid-cols-2 font-bold p-4">
                        <div>Profession</div>
                        <div>Count</div>
                    </div>
                    <div v-for="(count, profession) in professionCounts" :key="profession"
                        class="grid grid-cols-2 border-t py-2.5 px-4">
                        <div>{{ profession }}</div>
                        <div>{{ count }}</div>
                    </div>
                </div>
            </div>
        </div>
        <!-- <pre>
        {{ useEvaluationStats(genderEvaluations('Doctor')) }}
    </pre> -->
        <div class="pb-10" />
    </UContainer>

</template>