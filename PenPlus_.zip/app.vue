<template>
  <div>
    <NuxtRouteAnnouncer />
    <NuxtPage />
    <!-- <NuxtWelcome /> -->
  </div>
</template>
