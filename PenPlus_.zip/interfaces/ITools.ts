interface Tools {
    label: string,
    name: string,
    svg_path: string
}

type ITools = Readonly<Tools>;

export type { ITools as default };