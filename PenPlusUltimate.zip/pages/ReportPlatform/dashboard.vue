<script setup lang="ts">
import type IDistrict from "@/interfaces/IDistrict";
import Routes from '@/constants/Routes';
import DatabaseNames from "@/constants/DatabaseNames";


const facilities: Ref<Array<string>> = ref([])

const user = useUserDetails;

//districts

const useDistricts = useDistrictsStore();

const districts: Array<IDistrict> = await useDistricts.fetchDistricts();

districts?.forEach((d: any) => {
    facilities.value.push(d.facilities);
})

//mentees
const useMentees = useMenteeStore();

const mentees = await useMentees.fetchMentees();

//evaluations
const useEvaluations = useEvalDataStore();

const completedEvals = await useEvaluations.fetchEvaluationScores(DatabaseNames.COMPLETED_EVALUTATIONS);

const evaluationStats = useEvaluationStats(completedEvals)

//progress tracking
const tools = useTools


const countToolSessions = computed(() => {
    const arr: any[] = []
    tools.forEach((tool) => {
        const countSessions = useCountToolSessionsCompleted(tool.name, evaluationStats)
        arr.push({
            label: tool.label,
            name: tool.name,
            fiveCompleted: countSessions.allCompletedCount,
            fourCompleted: countSessions.fourCompleted,
            threeCompleted: countSessions.threeCompleted,
            twoCompleted: countSessions.twoCompletedCount,
            oneCompleted: countSessions.oneCompletedCount,
            totalCompleted: countSessions.totalCompletedCount
        })
    });

    return arr
})


const maxCompletedTool = countToolSessions.value.reduce((max, current) => {
    return (current.totalCompleted > max.totalCompleted) ? current : max;
});

const minCompletedTool = countToolSessions.value.reduce((min, current) => {
    return (current.totalCompleted < min.totalCompleted) ? current : min;
});

const totalSessionMinMaxTool = computed(() => {

    const maxEvals = maxCompletedTool.totalCompleted
    const maxSessions = maxCompletedTool.oneCompleted + 2 * maxCompletedTool.twoCompleted + 3 * maxCompletedTool.threeCompleted + 4 * maxCompletedTool.fourCompleted + 5 * maxCompletedTool.fiveCompleted

    ///
    const minEvals = minCompletedTool.totalCompleted
    const minSessions = minCompletedTool.oneCompleted + 2 * minCompletedTool.twoCompleted + 3 * minCompletedTool.threeCompleted + 4 * minCompletedTool.fourCompleted + 5 * minCompletedTool.fiveCompleted

    return {
        min: {
            evals: minEvals,
            sessions: minSessions
        },
        max: {
            evals: maxEvals,
            sessions: maxSessions
        }
    }

})

//
const countAllSessions = computed(() => {
    return (evaluationStats.completed1Evals.length + 2 * evaluationStats.completed2Evals.length + 3 * evaluationStats.completed3Evals.length + 4 * evaluationStats.completed4Evals.length + 5 * evaluationStats.completedEvaluations.length)
})

//

//districts

const countDistrictSessions = computed(() => {
    const arr: any[] = []
    districts.forEach((district) => {
        const countSessions = useCountDistrictSessionsCompleted(district.district, evaluationStats)
        arr.push({
            label: district.district,
            name: district.district,
            fiveCompleted: countSessions.allCompletedCount,
            fourCompleted: countSessions.fourCompletedCount,
            threeCompleted: countSessions.threeCompletedCount,
            twoCompleted: countSessions.twoCompletedCount,
            oneCompleted: countSessions.oneCompletedCount,
            totalCompleted: countSessions.totalCompletedCount
        })
    });

    return arr
})


const maxCompletedDistrict = countDistrictSessions.value.reduce((max, current) => {
    return (current.totalCompleted > max.totalCompleted) ? current : max;
});

const minCompletedDistrict = countDistrictSessions.value.reduce((min, current) => {
    return (current.totalCompleted < min.totalCompleted) ? current : min;
});

const totalSessionMinMaxDistrict = computed(() => {

    const maxEvals = maxCompletedDistrict.totalCompleted
    const maxSessions = maxCompletedDistrict.oneCompleted + 2 * maxCompletedDistrict.twoCompleted + 3 * maxCompletedDistrict.threeCompleted + 4 * maxCompletedDistrict.fourCompleted + 5 * maxCompletedDistrict.fiveCompleted

    ///
    const minEvals = minCompletedDistrict.totalCompleted
    const minSessions = minCompletedDistrict.oneCompleted + 2 * minCompletedDistrict.twoCompleted + 3 * minCompletedDistrict.threeCompleted + 4 * minCompletedDistrict.fourCompleted + 5 * minCompletedDistrict.fiveCompleted

    return {
        min: {
            evals: minEvals,
            sessions: minSessions
        },
        max: {
            evals: maxEvals,
            sessions: maxSessions
        }
    }

})

// facilities

const countFacilitySessions = computed(() => {
    const arr: any[] = []
    facilities.value.flat().forEach((facility) => {
        const countSessions = useCountFacilitySessionsCompleted(facility, evaluationStats)
        arr.push({
            label: facility,
            name: facility,
            fiveCompleted: countSessions.allCompletedCount,
            fourCompleted: countSessions.fourCompletedCount,
            threeCompleted: countSessions.threeCompletedCount,
            twoCompleted: countSessions.twoCompletedCount,
            oneCompleted: countSessions.oneCompletedCount,
            totalCompleted: countSessions.totalCompletedCount
        })
    });

    return arr
})


const maxCompletedFacility = countFacilitySessions.value.reduce((max, current) => {
    return (current.totalCompleted > max.totalCompleted) ? current : max;
});

const minCompletedFacility = countFacilitySessions.value.reduce((min, current) => {
    return (current.totalCompleted < min.totalCompleted) ? current : min;
});

const totalSessionMinMaxFacility = computed(() => {

    const maxEvals = maxCompletedFacility.totalCompleted
    const maxSessions = maxCompletedFacility.oneCompleted + 2 * maxCompletedFacility.twoCompleted + 3 * maxCompletedFacility.threeCompleted + 4 * maxCompletedFacility.fourCompleted + 5 * maxCompletedFacility.fiveCompleted

    ///
    const minEvals = minCompletedFacility.totalCompleted
    const minSessions = minCompletedFacility.oneCompleted + 2 * minCompletedFacility.twoCompleted + 3 * minCompletedFacility.threeCompleted + 4 * minCompletedFacility.fourCompleted + 5 * minCompletedFacility.fiveCompleted

    return {
        min: {
            evals: minEvals,
            sessions: minSessions
        },
        max: {
            evals: maxEvals,
            sessions: maxSessions
        }
    }

})


</script>

<template>
    <SharedNavBar>
        <template #lead>
            <div class="font-bold text-red-700">
                Dashboard
            </div>
        </template>
    </SharedNavBar>

    <UContainer>
        <UDivider label="Data" />

      <div class="py-5">
        A <span class="font-semibold text-orange-500">session</span> is a sitting between a provider (mentee) and a mentor, whereas an <span class="font-semibold text-green-500">evaluation</span> is a set of sessions
        possible to a mentee on a particular <span class="text-sky-500 font-semibold"> tool/disease </span> , so an evaluation can have a minimum of 1 session up to a maximum of 5 sessions per mentee per disease. So to date
        there has been: 
      </div>
            <!-- <template #body> -->
           <div class="grid grid-cols-2 gap-5">
            <div class="text-center border-r">
                <div class="font-bold py-5">Evaluations </div>
                <div class="text-5xl text-green-500 ">{{ completedEvals?.length
                }}</div>
            </div>
            <div class="text-center">
                <div class="font-bold py-5">Sessions </div>
                <div class="text-5xl text-orange-500 ">{{ countAllSessions
                }}</div>
            </div>
           </div>
            <!-- </template> -->
   
        <p class="pb-5 pt-10">
            To download all the evaluations to date, please click the button below. Data will be in csv format.
        </p>
        <div class="pb-5">
            <UButton variant="outline" color="orange" label="Download" @click="useDownloadEvaluations(completedEvals)">
                <template #trailing>
                    <UIcon name="i-heroicons-arrow-down-tray-20-solid" class="w-5 h-5" />
                </template>
            </UButton>
        </div>
        <UDivider label="Key Performance Indicators" />

        <div class="pt-5">
            Click on the cards below for detailed reports and analysis
        </div>
        <!-- Your content here -->
        <div class="flex justify-between pt-10 gap-5">
            <UCard
                class="flex-grow text-center text-sky-800 rounded-lg hover:bg-sky-400 hover:shadow-lg  hover:text-white">
                <NuxtLink :to="Routes.MENTEES_REPORTING.path">
                    <div class="border-b">Mentees/Providers</div>
                    <div class="text-5xl">{{ mentees?.length }}</div>
                </NuxtLink>
            </UCard>
            <UCard class="flex-grow text-center text-sky-800 rounded-lg hover:bg-sky-400 hover:shadow-lg  hover:text-white">
                <NuxtLink :to="Routes.TOOLS_REPORTING.path">
                    <div class="border-b">Tools</div>
                    <div class="text-5xl">{{ tools.length }}</div>
                </NuxtLink>
            </UCard>
            <UCard
                class="flex-grow text-center text-sky-800 rounded-lg hover:bg-sky-400 hover:shadow-lg  hover:text-white ">
                <NuxtLink :to="Routes.DISTRICTS_REPORTING.path">
                    <div class="border-b">Districts</div>
                    <div class="text-5xl ">{{ districts?.length }}</div>
                </NuxtLink>
            </UCard>

            <UCard
                class="flex-grow text-center text-sky-800 rounded-lg hover:bg-sky-400 hover:shadow-lg  hover:text-white">
                <NuxtLink :to="Routes.FACILITIES_REPORTING.path">
                    <div class="border-b">Facilities</div>
                    <div class="text-5xl">{{ facilities?.flat().length }}</div>
                </NuxtLink>
            </UCard>

        </div>
        <UDivider label="Progress Tracking" class="py-10" />

        <div class="pb-5">
            Tracking <span class=" text-sky-700 font-semibold">Tools/Diseases</span>
        </div>
        <div class="grid grid-cols-2 gap-5">
            <UCard class="bg-gray-100 ">
                <!-- <template #body> -->
                <div class="text-center">
                    <div class="font-bold py-5">Most Evaluated Tool </div>
                    <div class="text-5xl text-sky-500 ">{{ maxCompletedTool.label }}</div>
                </div>
                <!-- </template> -->
                <template #footer>
                    <div>
                        This tool has <span class="text-orange-500 font-semibold italic">{{
                            totalSessionMinMaxTool.max.evals }}</span> Evaluations amounting to <span
                            class="text-orange-500 font-semibold italic">{{ totalSessionMinMaxTool.max.sessions
                            }}</span> sessions
                    </div>
                </template>
            </UCard>

            <UCard class="bg-gray-100 ">
                <!-- <template #body> -->
                <div class="text-center">
                    <div class="font-bold py-5">Least Evaluated Tool </div>
                    <div class="text-5xl text-rose-500 ">{{ minCompletedTool.label }}</div>
                </div>
                <!-- </template> -->
                <template #footer>
                    <div>
                        This tool has <span class="text-orange-500 font-semibold italic">{{
                            totalSessionMinMaxTool.min.evals }}</span> Evaluations amounting to <span
                            class="text-orange-500 font-semibold italic">{{ totalSessionMinMaxTool.min.sessions
                            }}</span> sessions
                    </div>
                </template>
            </UCard>

        </div>

        <div class="py-5" />
        <div class="pb-5">
            Tracking <span class=" text-sky-700 font-semibold">Districts</span>
        </div>
        <div class="grid grid-cols-2 gap-5">
            <UCard class="bg-gray-100 ">
                <!-- <template #body> -->
                <div class="text-center">
                    <div class="font-bold py-5">District with Most Evaluations </div>
                    <div class="text-5xl text-sky-500 ">{{ maxCompletedDistrict.label }}</div>
                </div>
                <!-- </template> -->
                <template #footer>
                    <div>
                        This district has <span class="text-orange-500 font-semibold italic">{{
                            totalSessionMinMaxDistrict.max.evals }}</span> Evaluations amounting to <span
                            class="text-orange-500 font-semibold italic">{{ totalSessionMinMaxDistrict.max.sessions
                            }}</span> sessions
                    </div>
                </template>
            </UCard>

            <UCard class="bg-gray-100 ">
                <!-- <template #body> -->
                <div class="text-center">
                    <div class="font-bold py-5">District with Least Evaluations </div>
                    <div class="text-5xl text-rose-500 ">{{ minCompletedDistrict.label }}</div>
                </div>
                <!-- </template> -->
                <template #footer>
                    <div>
                        This district has <span class="text-orange-500 font-semibold italic">{{
                            totalSessionMinMaxDistrict.min.evals }}</span> Evaluations amounting to <span
                            class="text-orange-500 font-semibold italic">{{ totalSessionMinMaxDistrict.min.sessions
                            }}</span> sessions
                    </div>
                </template>
            </UCard>

        </div>

        <div class="py-5" />
        <div class="pb-5">
            Tracking <span class=" text-sky-700 font-semibold">Facilities</span>
        </div>
        <div class="grid grid-cols-2 gap-5">
            <UCard class="bg-gray-100 ">
                <!-- <template #body> -->
                <div class="text-center">
                    <div class="font-bold py-5">Facility with Most Evaluations </div>
                    <div class="text-5xl text-sky-500 ">{{ maxCompletedFacility.label }}</div>
                </div>
                <!-- </template> -->
                <template #footer>
                    <div>
                        This facility has <span class="text-orange-500 font-semibold italic">{{
                            totalSessionMinMaxFacility.max.evals }}</span> Evaluations amounting to <span
                            class="text-orange-500 font-semibold italic">{{ totalSessionMinMaxFacility.max.sessions
                            }}</span> sessions
                    </div>
                </template>
            </UCard>

            <UCard class="bg-gray-100 ">
                <!-- <template #body> -->
                <div class="text-center">
                    <div class="font-bold py-5">Facility with Least Evaluations </div>
                    <div class="text-5xl text-rose-500 ">{{ minCompletedFacility.label }}</div>
                </div>
                <!-- </template> -->
                <template #footer>
                    <div>
                        This facility has <span class="text-orange-500 font-semibold italic">{{
                            totalSessionMinMaxFacility.min.evals }}</span> Evaluations amounting to <span
                            class="text-orange-500 font-semibold italic">{{ totalSessionMinMaxFacility.min.sessions
                            }}</span> sessions
                    </div>
                </template>
            </UCard>

        </div>

        <div class="py-10" />
  
       
    </UContainer>
</template>

<style scoped>
/* Additional custom styles */

.text-pretty {
    color: #3B82F6;
    /* Sky color */
}

.icon-size {
    width: 100%;
    /* Fill the container width */
    height: auto;
    /* Maintain aspect ratio */
    max-height: 100px;
    /* Limit height for larger icons */
}

@media (max-width: 768px) {
    .text-lg {
        font-size: 1.5rem;
        /* Larger text on mobile */
    }

    .icon-size {
        max-height: 80px;
        /* Adjust icon size for smaller screens */
    }
}
</style>