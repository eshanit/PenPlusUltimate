import { defineStore } from "pinia";
import pouchDBConnect from "@/utilities/pouchDbConnect";
import type IMasterUser from "@/interfaces/IMasterUser";
import DatabaseNames from "@/constants/DatabaseNames";
import LocalStorageKeys from "@/constants/LocalStorageKeys";
import generateID from "@/utilities/generateID";
import useHash from "@/composables/useHash";
import { bcryptVerify } from "hash-wasm";
import Routes from "@/constants/Routes";



export const useAuthStore = defineStore("auth", () => {

    const user: Ref<null> = ref(null)
    const isLoggedIn: Ref<Boolean> = ref(false)
    const isRegistered: Ref<Boolean> = ref(false)
    const isAuthenticated: Ref<Boolean> = ref(false)
    const config = useRuntimeConfig();

    type CreateUser = Omit<IMasterUser, "_rev" | "searchIndex" | "updatedAt" | "updatedBy">

    const db = pouchDBConnect(DatabaseNames.USERS);
    const remoteDB = pouchDBConnect(`${config.public.couchDBUrl}/${DatabaseNames.USERS}`);
 
    /**
     * register a user
     */

    const registerUser = async (userRegData: CreateUser) => {

        const CreateUserData = {
            _id: generateID(),
            firstname: userRegData.firstname,
            lastname: userRegData.lastname,
            username: userRegData.username,
            password: await useHash(userRegData.password),
            terms: userRegData.terms,
        };

        console.log('CreateUser:',CreateUserData);

        db.put(CreateUserData).then(async () => {
            await navigateTo(Routes.INDEX);
        }).then(() => {
            remoteDB.logIn(config.public.couchDBUsername, config.public.couchDBPassword).then(() => {
                db.sync(remoteDB, {
                    live: true,
                    retry: true,
                }).on("change", (change: any) => {
                    console.log("something changed", change);
                });
            });
        }).catch((error: Error) => {
            console.error("register failed", error);
        });

        isRegistered.value = true;

    }

    /**
     *  Sign in a user
     */
    const signIn = async (userData: Pick<IMasterUser, "username" | "password">): Promise<boolean | void> => {

        db.createIndex({ index: { fields: ["username"] } });
    
        const userAuthenticated = await db.find({
          selector: {
            username: userData.username,
          },
        }).then(async function (response: { docs: { [x: string]: any; password: any; }[]; }) {
    
          const isValid = await bcryptVerify({
            password: userData.password,
            hash: response.docs[0].password,
          });
    
          if (isValid) {
            
            localStorage.clear()
    
            const profileData = {
              id: response.docs[0]._id,
              firstname: response.docs[0].firstname,
              lastname: response.docs[0].lastname,
              username: response.docs[0].username,
              searchIndex: (response.docs[0].firstname.concat(response.docs[0].lastname)).toLowerCase()
            }
    
            useProcessLocalStorage().store(LocalStorageKeys.PROFILE, profileData)
    
          }
    
          return isValid;
        })
          .catch(function (err: any) {
            console.log(err);
          });
    
    
    
        if (userAuthenticated) {
          const token = useCookie('token')
          token.value = generateID()
          isLoggedIn.value = userAuthenticated;
          isAuthenticated.value = userAuthenticated;
    
          await navigateTo(Routes.DASHBOARD);
    
        } else {
    
          await navigateTo(Routes.INDEX);
    
          alert('Wrong Credentials. Please try again')
        }
    
        return userAuthenticated;
      };

      /**
       * Signout a user
       */
      const signOut = async () => {
        localStorage.clear()
        isAuthenticated.value = false;
        isLoggedIn.value = false;
    
        const token = useCookie('token');
        token.value = null;
        await navigateTo(Routes.INDEX);
      }

    return { user, registerUser, signIn, signOut, isRegistered, isLoggedIn, isAuthenticated };

})