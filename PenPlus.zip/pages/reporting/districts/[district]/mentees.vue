<script setup lang="ts">

const router = useRouter()
const goBack = () => {
    router.back();
};

const route = useRoute()
const district: any = route.params.district

//mentees
const useMentees = useMenteeStore();

const mentees = await useMentees.fetchDistrictMentees(district);
</script>
<template>
    <SharedBorderedNavBar>
        <template #lead>
            <!-- <NuxtLink :to="Routes.COMPLETED_EVALUATIONS.path"> -->
            <div class="pr-5 text-blue-500 cursor-pointer" @click="goBack">
                <UIcon name="i-heroicons-arrow-small-left" />
            </div>
            <!-- </NuxtLink> -->
            <div>
                <span class=" text-gray-400"><strong>Districts</strong></span> | <span
                    class=" text-green-500 font-bold">{{ district }}</span> |<span class=" text-orange-500">
                    Mentees</span>
            </div>
        </template>
    </SharedBorderedNavBar>

    <UContainer>
        <div class="py-5">
            <p> There are <span class="text-green-500">{{ mentees.length }}</span> in this district</p> 
            <p>List of mentees/providers in <span class="text-orange-500">{{ district }}</span> district.</p>
            
        </div>
        <TablesAGtablesMenteesList :mentees="mentees" />
    </UContainer>
</template>