<script setup lang="ts">
import Routes from "@/constants/Routes";
import { format } from 'date-fns'
import LocalStorageKeys from "@/constants/LocalStorageKeys";

const route = useRoute()
const tool = route.params.tool

const showSummary: Ref<Boolean> = ref(false)

// const selectedTool: Ref<any> = ref()
// selectedTool.value = useProcessLocalStorage().retrieve(LocalStorageKeys.TOOL)

const now = new Date(Date.now());
const formattedDate = format(now, 'MMMM dd, yyyy'); // Example format



const menteeData: any = useProcessLocalStorage().retrieve(LocalStorageKeys.EVALUATED_MENTEE)

const scoreMarks: any = useProcessLocalStorage().retrieve(LocalStorageKeys.SCORES)

const scoreCounts = useScoreCount(scoreMarks.evalItemScores)
const scoreStats = useScoreStatistics(scoreMarks.evalItemScores)


const useEvaluationStore = useEvalDataStore()


const evalSession: any = useProcessLocalStorage().retrieve(LocalStorageKeys.EVALUATION_SESSION)

const submitScores = async () => {

    console.log('evalSession', evalSession)

    if (evalSession == '1') {
        await useEvaluationStore.storeScores(tool)
    } else {
        await useEvaluationStore.createSessionEval()
    }


}

const router = useRouter();

const goBack = () => {
  router.back();
};



</script>
<template>
    <!-- <pre>
        {{ useScoreCount(scoreMarks.evalItemScores) }}
    </pre> -->
    <SharedBorderedNavBar>
        <template #lead>
            <div v-show="!showSummary">
                <!-- <NuxtLink :to="Routes.PREVIEW.path"> -->
                    <div class="pr-5 text-blue-500 cursor-pointer" @click="goBack">
                        <UIcon name="i-heroicons-arrow-small-left" />
                    </div>
                <!-- </NuxtLink> -->
            </div>
            <div v-show="showSummary">
                <div class="pr-5 text-blue-500 cursor-pointer" @click="showSummary = false">
                    <UIcon name="i-heroicons-arrow-small-left" />
                </div>
            </div>

            <div>
                <span class=" text-gray-400"><strong>Evaluating</strong></span> | <span class=" text-sky-700"> {{
                    tool }}</span>
            </div>
        </template>
    </SharedBorderedNavBar>
    <UContainer>
        <!-- <pre>
        {{ scoreMarks }}
    </pre> -->



        <div>
            <div class="py-2.5 font-bold text-orange-500">
                Score Preview
            </div>
            <SharedTwCardWithHeader>
                <template #header>
                    Mentee Information
                </template>
                <template #body>
                    <div class="flex gap-4 py-2.5">
                        <div class=" text-sky-600">
                            <strong>Mentee Name:</strong>
                        </div>
                        <div>
                            {{ menteeData.firstname }} {{ menteeData.lastname }}
                        </div>
                    </div>
                    <div class="flex gap-4 py-2.5">
                        <div class=" text-sky-600">
                            <strong>Session:</strong>
                        </div>
                        <div>
                            {{ evalSession }}
                        </div>
                    </div>
                    <div class="flex gap-4 py-2.5">
                        <div class=" text-sky-600">
                            <strong>Date:</strong>
                        </div>
                        <div>
                            {{ formattedDate }}
                        </div>
                    </div>
                </template>
            </SharedTwCardWithHeader>
            <UDivider class="py-5" />
            <SharedTwCardWithHeader>
                <template #header>
                    <span class=" font-bold text-sky-600"> Score Counts </span>
                </template>
                <template #body>

                    <div class=" py-2.5">
                        <UCard class=" bg-slate-50">
                            <div class=" flex justify-between">
                                <div>Items with a score of 0 </div>
                                <div>
                                    <UDivider orientation="vertical" />
                                </div>
                                <div class=" text-3xl text-zinc-500 font-bold">
                                    <span v-if="scoreCounts[0]">
                                        {{ scoreCounts[0] }}
                                    </span>
                                    <span v-else>
                                        0
                                    </span>
                                </div>
                            </div>
                        </UCard>
                    </div>

                    <div class=" py-2.5">
                        <UCard class=" bg-yellow-400">
                            <div class=" flex justify-between">
                                <div>Items with a score of 1 </div>
                                <div>
                                    <UDivider orientation="vertical" />
                                </div>
                                <div class=" text-3xl text-zinc-500 font-bold">
                                    <span v-if="scoreCounts[1]">
                                        {{ scoreCounts[1] }}
                                    </span>
                                    <span v-else>
                                        0
                                    </span>
                                </div>
                            </div>
                        </UCard>
                    </div>

                    <div class=" py-2.5">
                        <UCard class=" bg-yellow-200">
                            <div class=" flex justify-between">
                                <div>Items with a score of 2 </div>
                                <div>
                                    <UDivider orientation="vertical" />
                                </div>
                                <div class=" text-3xl text-zinc-500 font-bold">
                                    <span v-if="scoreCounts[2]">
                                        {{ scoreCounts[2] }}
                                    </span>
                                    <span v-else>
                                        0
                                    </span>
                                </div>
                            </div>
                        </UCard>
                    </div>


                    <div class=" py-2.5">
                        <UCard class=" bg-green-200">
                            <div class=" flex justify-between">
                                <div>Items with a score of 3 </div>
                                <div>
                                    <UDivider orientation="vertical" />
                                </div>
                                <div class=" text-3xl text-zinc-500 font-bold">
                                    <span v-if="scoreCounts[3]">
                                        {{ scoreCounts[3] }}
                                    </span>
                                    <span v-else>
                                        0
                                    </span>
                                </div>
                            </div>
                        </UCard>
                    </div>

                    <div class=" py-2.5">
                        <UCard class=" bg-green-300">
                            <div class=" flex justify-between">
                                <div>Items with a score of 4 </div>
                                <div>
                                    <UDivider orientation="vertical" />
                                </div>
                                <div class=" text-3xl text-zinc-500 font-bold">
                                    <span v-if="scoreCounts[4]">
                                        {{ scoreCounts[4] }}
                                    </span>
                                    <span v-else>
                                        0
                                    </span>
                                </div>
                            </div>
                        </UCard>
                    </div>

                    <div class=" py-2.5">
                        <UCard class=" bg-green-400">
                            <div class=" flex justify-between">
                                <div>Items with a score of 5 </div>
                                <div>
                                    <UDivider orientation="vertical" />
                                </div>
                                <div class=" text-3xl text-zinc-500 font-bold">
                                    <span v-if="scoreCounts[5]">
                                        {{ scoreCounts[5] }}
                                    </span>
                                    <span v-else>
                                        0
                                    </span>
                                </div>
                            </div>
                        </UCard>
                    </div>
                </template>
            </SharedTwCardWithHeader>
            <UDivider class="py-5" />

            <!-- ... previous code remains the same -->
            <SharedTwCardWithHeader>
                <!-- ... previous code remains the same -->
                <template #body>
                    <!-- ... previous code remains the same -->
                    <div class=" flex justify-between">
                        <div>
                            Mean Score
                        </div>
                        <div class=" text-red-500 text-3xl font-bold">
                            {{ scoreStats.mean.value.toFixed(2) }}
                        </div>
                    </div>
                </template>
            </SharedTwCardWithHeader>
            <!-- ... previous code remains the same -->

        </div>


        <UDivider class="py-5" />
        <div class=" flex justify-end py-5">
            <div class=" flex gap-1">

                <NuxtLink :to="{
                    name: Routes.EVALUATION_TOOL.name,
                    params: {
                        tool: tool,
                    }
                }">
                    <UButton icon="i-heroicons-chevron-double-left" variant="outline" color="orange" size="xl">Back
                    </UButton>
                </NuxtLink>
                <UButton color="green" size="xl" @click="submitScores()"> Submit Scores </UButton>


            </div>
        </div>

    </UContainer>
</template>